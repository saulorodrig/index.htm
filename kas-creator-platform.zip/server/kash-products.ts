import { brlCentsToKashMilli } from "../shared/kash";

export const KASH_PACKAGES = {
  starter: {
    id: "starter",
    label: "Kash Start",
    brlCents: 500,
    kashMilli: brlCentsToKashMilli(500),
  },
  supporter: {
    id: "supporter",
    label: "Kash Supporter",
    brlCents: 1_500,
    kashMilli: brlCentsToKashMilli(1_500),
  },
  creator: {
    id: "creator",
    label: "Kash Creator",
    brlCents: 3_000,
    kashMilli: brlCentsToKashMilli(3_000),
  },
} as const;

export type KashPackageId = keyof typeof KASH_PACKAGES;

export function getKashPackage(id: KashPackageId) {
  return KASH_PACKAGES[id];
}
