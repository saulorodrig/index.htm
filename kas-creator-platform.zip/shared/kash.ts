export const KASH_PER_BRL = 10;
export const KASH_MILLI_PER_KASH = 1_000;
export const MINIMUM_WITHDRAWAL_CENTS = 5_000;
export const MINIMUM_VIEW_RETENTION_MS = 3_000;
export const CREATOR_SHARE_BPS = 8_500;
export const PLATFORM_SHARE_BPS = 1_500;

export type KashSplit = {
  creatorKashMilli: number;
  platformKashMilli: number;
};

export function brlCentsToKashMilli(brlCents: number): number {
  if (!Number.isInteger(brlCents) || brlCents < 0) {
    throw new Error("O valor em centavos deve ser um inteiro não negativo.");
  }

  return brlCents * KASH_PER_BRL * 10;
}

export function kashMilliToBrlCents(kashMilli: number): number {
  if (!Number.isInteger(kashMilli) || kashMilli < 0) {
    throw new Error("O saldo Kash deve ser um inteiro não negativo.");
  }

  return Math.floor(kashMilli / (KASH_PER_BRL * 10));
}

export function calculateKashSplit(kashMilli: number): KashSplit {
  if (!Number.isInteger(kashMilli) || kashMilli <= 0) {
    throw new Error("O apoio deve ser um valor Kash positivo.");
  }

  const creatorKashMilli = Math.floor((kashMilli * CREATOR_SHARE_BPS) / 10_000);
  return {
    creatorKashMilli,
    platformKashMilli: kashMilli - creatorKashMilli,
  };
}

export function isValidViewRetention(retentionMs: number): boolean {
  return Number.isFinite(retentionMs) && retentionMs >= MINIMUM_VIEW_RETENTION_MS;
}
