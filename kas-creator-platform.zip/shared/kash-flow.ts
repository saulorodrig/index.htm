import { MINIMUM_WITHDRAWAL_CENTS } from "./kash";

export type PayoutEligibility = {
  brlBalanceCents: number;
  kycStatus: "not_started" | "pending" | "verified" | "rejected";
  payoutsEnabled: number;
  stripeAccountId: string | null;
};

export function assertCreatorSupport(input: { senderUserId: number; creatorUserId: number; senderKashMilli: number; kashMilli: number }) {
  if (input.senderUserId === input.creatorUserId) throw new Error("Não é possível apoiar a própria conta.");
  if (input.kashMilli <= 0) throw new Error("O apoio deve ser positivo.");
  if (input.senderKashMilli < input.kashMilli) throw new Error("Saldo Kash insuficiente.");
}

export function assertPayoutEligibility(wallet: PayoutEligibility, brlCents: number) {
  if (brlCents < MINIMUM_WITHDRAWAL_CENTS) throw new Error("O saque mínimo é de R$ 50,00.");
  if (wallet.kycStatus !== "verified" || wallet.payoutsEnabled !== 1) throw new Error("Conclua a validação KYC antes de solicitar um saque.");
  if (!wallet.stripeAccountId) throw new Error("Conclua o onboarding de recebimento antes de solicitar um saque.");
  if (wallet.brlBalanceCents < brlCents) throw new Error("Saldo disponível em BRL insuficiente.");
}

export function shouldCreditPaymentIntent(existingTransactionId: number | undefined): boolean {
  return existingTransactionId === undefined;
}
