import { describe, expect, it } from "vitest";
import type { TrpcContext } from "./_core/context";
import { appRouter } from "./routers";
import { normalizeHashtags } from "./db";
import { getGiftBySlug } from "../shared/gifts";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createContext(): TrpcContext {
  const user: AuthenticatedUser = {
    id: 7,
    openId: "kas-test-user",
    email: "creator@kas.test",
    name: "Creator KAS",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
    handle: "creator-kas",
    bio: null,
    avatarUrl: null,
    followerCount: 0,
    followingCount: 0,
    creatorStatus: "active",
  };

  return {
    user,
    req: { protocol: "https", headers: { origin: "https://kas.test" } } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("KAS creator platform guardrails", () => {
  it("blocks self-follow attempts", async () => {
    const caller = appRouter.createCaller(createContext());
    await expect(caller.kas.social.toggleFollow({ userId: 7 })).rejects.toThrow("não pode seguir a si mesmo");
  });

  it("rejects unsupported media before storage upload", async () => {
    const caller = appRouter.createCaller(createContext());
    await expect(caller.kas.media.upload({ kind: "video", mimeType: "application/pdf", base64: "cGRm" })).rejects.toThrow("Formato de mídia não permitido");
  });

  it("blocks self-support attempts", async () => {
    const caller = appRouter.createCaller(createContext());
    await expect(caller.kas.wallet.supportCreator({ creatorUserId: 7, kashMilli: 1_000 })).rejects.toThrow("própria conta");
  });

  it("normalizes and deduplicates hashtags", () => {
    expect(normalizeHashtags("#Visual #visual #Música, #night-shift")).toBe("visual,musica,night-shift");
  });

  it("resolves the original lion-signal gift from the catalog", () => {
    expect(getGiftBySlug("lion-signal")).toMatchObject({ label: "Leão Solar", effectKey: "lion-signal", costKash: 500 });
  });

  it("rejects an unknown live gift", async () => {
    const caller = appRouter.createCaller(createContext());
    await expect(caller.kas.live.sendGift({ roomId: 1, creatorUserId: 7, giftSlug: "not-a-gift" })).rejects.toThrow("Presente não encontrado");
  });

  it("rejects an empty discovery term", async () => {
    const caller = appRouter.createCaller(createContext());
    await expect(caller.kas.discover.search({ term: " " })).rejects.toThrow();
  });

  it("rejects invalid view retention values", async () => {
    const caller = appRouter.createCaller(createContext());
    await expect(caller.kas.feed.recordView({ videoId: 1, retainedMs: -1 })).rejects.toThrow();
  });
});
