export type FeedShortcut = "previous" | "next" | "toggle-play" | "toggle-mute" | null;

export function getFeedShortcut(key: string, isEditing: boolean): FeedShortcut {
  if (isEditing) return null;
  if (key === "ArrowUp") return "previous";
  if (key === "ArrowDown") return "next";
  if (key === " ") return "toggle-play";
  if (key.toLowerCase() === "m") return "toggle-mute";
  return null;
}

export function executeFeedShortcut(input: {
  key: string;
  isEditing: boolean;
  preventDefault: () => void;
  onPrevious: () => void;
  onNext: () => void;
  onTogglePlay: () => void;
  onToggleMute: () => void;
}): boolean {
  const shortcut = getFeedShortcut(input.key, input.isEditing);
  if (!shortcut) return false;
  input.preventDefault();
  if (shortcut === "previous") input.onPrevious();
  if (shortcut === "next") input.onNext();
  if (shortcut === "toggle-play") input.onTogglePlay();
  if (shortcut === "toggle-mute") input.onToggleMute();
  return true;
}
