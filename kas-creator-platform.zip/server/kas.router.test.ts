import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

function createContext(): TrpcContext {
  return {
    user: {
      id: 17,
      openId: "kas-test-user",
      name: "Kas Test",
      email: "test@kas.local",
      loginMethod: "manus",
      role: "creator",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: { headers: { origin: "https://kas.local" } } as TrpcContext["req"],
    res: { clearCookie: () => undefined } as TrpcContext["res"],
  };
}

describe("contratos tRPC do kas", () => {
  it("rejeita apoio à própria conta antes de tocar no banco", async () => {
    const caller = appRouter.createCaller(createContext());
    await expect(caller.kas.wallet.supportCreator({ creatorUserId: 17, kashMilli: 1_000 })).rejects.toMatchObject({
      code: "BAD_REQUEST",
    });
  });

  it("rejeita saque abaixo do mínimo regulado", async () => {
    const caller = appRouter.createCaller(createContext());
    await expect(caller.kas.wallet.requestPayout({ brlCents: 4_999 })).rejects.toMatchObject({
      code: "BAD_REQUEST",
    });
  });

  it("rejeita evento de visualização com retenção inválida", async () => {
    const caller = appRouter.createCaller(createContext());
    await expect(caller.kas.feed.recordView({ videoId: 1, retainedMs: -1 })).rejects.toMatchObject({
      code: "BAD_REQUEST",
    });
  });

  it("rejeita mídia fora da lista permitida antes do armazenamento", async () => {
    const caller = appRouter.createCaller(createContext());
    await expect(caller.kas.media.upload({ kind: "avatar", mimeType: "text/plain", base64: "a2Fz" })).rejects.toMatchObject({
      code: "BAD_REQUEST",
    });
  });
});
