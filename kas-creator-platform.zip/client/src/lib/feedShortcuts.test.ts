import { describe, expect, it } from "vitest";
import { executeFeedShortcut, getFeedShortcut } from "./feedShortcuts";

describe("atalhos do feed kas", () => {
  it("mapeia ↑, ↓, Espaço e M para as ações do player", () => {
    expect(getFeedShortcut("ArrowUp", false)).toBe("previous");
    expect(getFeedShortcut("ArrowDown", false)).toBe("next");
    expect(getFeedShortcut(" ", false)).toBe("toggle-play");
    expect(getFeedShortcut("m", false)).toBe("toggle-mute");
  });

  it("não intercepta atalhos enquanto o usuário digita", () => {
    expect(getFeedShortcut("ArrowDown", true)).toBeNull();
  });

  it("executa os callbacks do player para eventos de teclado", () => {
    const calls = { previous: 0, next: 0, play: 0, mute: 0, prevented: 0 };
    const base = {
      isEditing: false,
      preventDefault: () => { calls.prevented += 1; },
      onPrevious: () => { calls.previous += 1; },
      onNext: () => { calls.next += 1; },
      onTogglePlay: () => { calls.play += 1; },
      onToggleMute: () => { calls.mute += 1; },
    };
    executeFeedShortcut({ ...base, key: "ArrowUp" });
    executeFeedShortcut({ ...base, key: "ArrowDown" });
    executeFeedShortcut({ ...base, key: " " });
    executeFeedShortcut({ ...base, key: "M" });
    expect(calls).toEqual({ previous: 1, next: 1, play: 1, mute: 1, prevented: 4 });
  });
});
