-- kas — Schema PostgreSQL de referência para produção
-- Valores monetários são armazenados em centavos BRL e milésimos de Kash.

CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TYPE kas_user_role AS ENUM ('user', 'creator', 'admin');
CREATE TYPE kyc_status AS ENUM ('not_started', 'pending', 'verified', 'rejected');
CREATE TYPE video_visibility AS ENUM ('public', 'unlisted', 'private');
CREATE TYPE video_status AS ENUM ('draft', 'processing', 'published', 'rejected');
CREATE TYPE transaction_type AS ENUM ('kash_purchase', 'creator_support', 'creator_earning', 'payout_request', 'payout_completed', 'refund');
CREATE TYPE transaction_status AS ENUM ('pending', 'completed', 'failed', 'cancelled');

CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  external_auth_id VARCHAR(128) UNIQUE,
  email VARCHAR(320) UNIQUE,
  display_name VARCHAR(120) NOT NULL,
  handle VARCHAR(40) NOT NULL UNIQUE,
  role kas_user_role NOT NULL DEFAULT 'user',
  bio VARCHAR(280),
  avatar_storage_key VARCHAR(512),
  avatar_url TEXT,
  follower_count BIGINT NOT NULL DEFAULT 0 CHECK (follower_count >= 0),
  following_count BIGINT NOT NULL DEFAULT 0 CHECK (following_count >= 0),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE wallets (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
  brl_balance_cents BIGINT NOT NULL DEFAULT 0 CHECK (brl_balance_cents >= 0),
  kash_milli_balance BIGINT NOT NULL DEFAULT 0 CHECK (kash_milli_balance >= 0),
  pending_payout_cents BIGINT NOT NULL DEFAULT 0 CHECK (pending_payout_cents >= 0),
  kyc_status kyc_status NOT NULL DEFAULT 'not_started',
  stripe_customer_id VARCHAR(255) UNIQUE,
  stripe_account_id VARCHAR(255) UNIQUE,
  payouts_enabled BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE videos (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  creator_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title VARCHAR(140) NOT NULL,
  description TEXT,
  video_storage_key VARCHAR(512),
  video_url TEXT NOT NULL,
  thumbnail_storage_key VARCHAR(512),
  thumbnail_url TEXT,
  mime_type VARCHAR(80),
  duration_ms INTEGER NOT NULL CHECK (duration_ms > 0),
  visibility video_visibility NOT NULL DEFAULT 'public',
  status video_status NOT NULL DEFAULT 'draft',
  total_views BIGINT NOT NULL DEFAULT 0 CHECK (total_views >= 0),
  total_likes BIGINT NOT NULL DEFAULT 0 CHECK (total_likes >= 0),
  average_retention_ms INTEGER NOT NULL DEFAULT 0 CHECK (average_retention_ms >= 0),
  published_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE video_likes (
  video_id UUID NOT NULL REFERENCES videos(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  PRIMARY KEY (video_id, user_id)
);

CREATE TABLE video_comments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  video_id UUID NOT NULL REFERENCES videos(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  content VARCHAR(500) NOT NULL CHECK (char_length(trim(content)) > 0),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE video_view_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  video_id UUID NOT NULL REFERENCES videos(id) ON DELETE CASCADE,
  viewer_user_id UUID REFERENCES users(id) ON DELETE SET NULL,
  retention_ms INTEGER NOT NULL CHECK (retention_ms >= 0),
  is_valid BOOLEAN NOT NULL DEFAULT FALSE,
  session_hash VARCHAR(128),
  ip_hash VARCHAR(128),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE transactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  type transaction_type NOT NULL,
  status transaction_status NOT NULL DEFAULT 'pending',
  sender_wallet_id UUID REFERENCES wallets(id) ON DELETE SET NULL,
  receiver_wallet_id UUID REFERENCES wallets(id) ON DELETE SET NULL,
  video_id UUID REFERENCES videos(id) ON DELETE SET NULL,
  kash_milli_amount BIGINT NOT NULL DEFAULT 0 CHECK (kash_milli_amount >= 0),
  creator_kash_milli BIGINT NOT NULL DEFAULT 0 CHECK (creator_kash_milli >= 0),
  platform_kash_milli BIGINT NOT NULL DEFAULT 0 CHECK (platform_kash_milli >= 0),
  brl_cents_amount BIGINT NOT NULL DEFAULT 0 CHECK (brl_cents_amount >= 0),
  stripe_payment_intent_id VARCHAR(255) UNIQUE,
  stripe_payout_id VARCHAR(255) UNIQUE,
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CHECK (
    type <> 'creator_support'
    OR creator_kash_milli + platform_kash_milli = kash_milli_amount
  )
);

CREATE INDEX users_creator_idx ON users(role) WHERE role = 'creator';
CREATE INDEX videos_feed_idx ON videos(status, visibility, published_at DESC) WHERE status = 'published' AND visibility = 'public';
CREATE INDEX videos_creator_published_idx ON videos(creator_id, published_at DESC);
CREATE INDEX video_comments_video_created_idx ON video_comments(video_id, created_at DESC);
CREATE INDEX video_view_events_video_created_idx ON video_view_events(video_id, created_at DESC);
CREATE INDEX video_view_events_fraud_idx ON video_view_events(video_id, session_hash, created_at DESC);
CREATE INDEX transactions_sender_created_idx ON transactions(sender_wallet_id, created_at DESC);
CREATE INDEX transactions_receiver_created_idx ON transactions(receiver_wallet_id, created_at DESC);
CREATE INDEX transactions_type_status_idx ON transactions(type, status, created_at DESC);
