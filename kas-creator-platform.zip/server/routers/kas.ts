import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { nanoid } from "nanoid";
import {
  blockUser,
  createComment,
  createCreatorVideo,
  createLiveMessage,
  createModerationReport,
  getCommentsForVideo,
  getCommunityById,
  getCommunityMissions,
  getCommunities,
  getCreatorContentById,
  getCreatorStudioSummary,
  getFeed,
  searchDiscovery,
  sendLiveGift,
  getLiveMessages,
  getLiveRooms,
  getNotificationsForUser,
  getWalletByUserId,
  getWalletLedger,
  failPayoutRequest,
  markNotificationsRead,
  markPayoutSubmitted,
  recordView,
  requestCreatorPayout,
  supportCreator,
  toggleFollow,
  toggleVideoLike,
} from "../db";
import { KASH_MILLI_PER_KASH } from "../../shared/kash";
import { getGiftBySlug } from "../../shared/gifts";
import { createCommunitySubscriptionCheckoutSession, createCreatorOnboardingLink, createExclusiveCheckoutSession, createKashCheckoutSession, sendCreatorTransfer } from "../stripe";
import { storagePut } from "../storage";
import { publicProcedure, protectedProcedure, router } from "../_core/trpc";

const kashAmountSchema = z.number().int().min(KASH_MILLI_PER_KASH, "O apoio mínimo é de 1 Kash.");
const mediaInput = z.object({ kind: z.enum(["avatar", "thumbnail", "video"]), mimeType: z.string().max(80), base64: z.string().min(1).max(7_000_000) });

function validateMedia(kind: "avatar" | "thumbnail" | "video", mimeType: string, bytes: Buffer) {
  const isImage = ["image/jpeg", "image/png", "image/webp"].includes(mimeType);
  const isVideo = ["video/mp4", "video/webm"].includes(mimeType);
  const validType = kind === "video" ? isVideo : isImage;
  const maxBytes = kind === "video" ? 5 * 1024 * 1024 : 3 * 1024 * 1024;
  if (!validType) throw new TRPCError({ code: "BAD_REQUEST", message: "Formato de mídia não permitido." });
  if (bytes.byteLength > maxBytes) throw new TRPCError({ code: "PAYLOAD_TOO_LARGE", message: "O arquivo excede o limite permitido para este MVP." });
}

export const kasRouter = router({
  discover: router({
    search: publicProcedure.input(z.object({ term: z.string().trim().min(1).max(80), limit: z.number().int().min(1).max(20).optional() })).query(({ input }) => searchDiscovery(input)),
  }),
  feed: router({
    list: publicProcedure.input(z.object({ limit: z.number().int().min(1).max(20).optional() }).optional()).query(({ input }) => getFeed(input?.limit ?? 10)),
    recordView: publicProcedure.input(z.object({ videoId: z.number().int().positive(), retainedMs: z.number().int().nonnegative() })).mutation(({ ctx, input }) => recordView({ ...input, viewerUserId: ctx.user?.id ?? null })),
    toggleLike: protectedProcedure.input(z.object({ videoId: z.number().int().positive() })).mutation(({ ctx, input }) => toggleVideoLike({ videoId: input.videoId, userId: ctx.user.id })),
    comments: publicProcedure.input(z.object({ videoId: z.number().int().positive() })).query(({ input }) => getCommentsForVideo(input.videoId)),
    createComment: protectedProcedure.input(z.object({ videoId: z.number().int().positive(), content: z.string().trim().min(1).max(500) })).mutation(({ ctx, input }) => createComment({ ...input, userId: ctx.user.id })),
  }),
  social: router({
    toggleFollow: protectedProcedure.input(z.object({ userId: z.number().int().positive() })).mutation(({ ctx, input }) => {
      if (ctx.user.id === input.userId) throw new TRPCError({ code: "BAD_REQUEST", message: "Você não pode seguir a si mesmo." });
      return toggleFollow({ followerId: ctx.user.id, followingId: input.userId });
    }),
  }),
  live: router({
    list: publicProcedure.input(z.object({ limit: z.number().int().min(1).max(20).optional() }).optional()).query(({ input }) => getLiveRooms(input?.limit ?? 10)),
    messages: publicProcedure.input(z.object({ roomId: z.number().int().positive() })).query(({ input }) => getLiveMessages(input.roomId)),
    sendMessage: protectedProcedure.input(z.object({ roomId: z.number().int().positive(), body: z.string().trim().min(1).max(280) })).mutation(({ ctx, input }) => createLiveMessage({ ...input, userId: ctx.user.id })),
    sendGift: protectedProcedure.input(z.object({ roomId: z.number().int().positive(), creatorUserId: z.number().int().positive(), giftSlug: z.string().trim().min(1).max(60) })).mutation(({ ctx, input }) => {
      const gift = getGiftBySlug(input.giftSlug);
      if (!gift) throw new TRPCError({ code: "NOT_FOUND", message: "Presente não encontrado." });
      if (ctx.user.id === input.creatorUserId) throw new TRPCError({ code: "BAD_REQUEST", message: "Não é possível enviar presente para si mesmo." });
      return sendLiveGift({ senderUserId: ctx.user.id, creatorUserId: input.creatorUserId, roomId: input.roomId, giftName: gift.label, kashMilli: gift.costKash * KASH_MILLI_PER_KASH });
    }),
  }),
  communities: router({
    list: publicProcedure.input(z.object({ limit: z.number().int().min(1).max(20).optional() }).optional()).query(({ input }) => getCommunities(input?.limit ?? 10)),
    missions: publicProcedure.input(z.object({ communityId: z.number().int().positive() })).query(({ input }) => getCommunityMissions(input.communityId)),
  }),
  creator: router({
    studio: protectedProcedure.query(({ ctx }) => getCreatorStudioSummary(ctx.user.id)),
    publish: protectedProcedure.input(z.object({ title: z.string().trim().min(1).max(140), description: z.string().trim().max(500).default(""), hashtags: z.string().trim().max(500).optional(), videoUrl: z.string().url(), videoStorageKey: z.string().max(512).optional(), thumbnailUrl: z.string().url().optional(), thumbnailStorageKey: z.string().max(512).optional(), durationMs: z.number().int().positive(), accessType: z.enum(["public", "community", "paid"]).default("public"), priceCents: z.number().int().min(0).default(0) })).mutation(({ ctx, input }) => createCreatorVideo({ ...input, creatorId: ctx.user.id })),
    exclusiveCheckout: protectedProcedure.input(z.object({ contentId: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
      const record = await getCreatorContentById(input.contentId);
      if (!record) throw new TRPCError({ code: "NOT_FOUND", message: "Conteúdo não encontrado." });
      const origin = ctx.req.headers.origin;
      if (!origin) throw new TRPCError({ code: "BAD_REQUEST", message: "A origem da solicitação é obrigatória." });
      const session = await createExclusiveCheckoutSession({ contentId: record.content.id, title: record.content.title, priceCents: record.content.priceCents, creatorId: record.content.creatorId, userId: ctx.user.id, userName: ctx.user.name, userEmail: ctx.user.email, origin });
      return { checkoutUrl: session.url };
    }),
  }),
  notifications: router({
    list: protectedProcedure.query(({ ctx }) => getNotificationsForUser(ctx.user.id)),
    markRead: protectedProcedure.mutation(({ ctx }) => markNotificationsRead(ctx.user.id)),
  }),
  moderation: router({
    report: protectedProcedure.input(z.object({ targetUserId: z.number().int().positive().optional(), videoId: z.number().int().positive().optional(), liveRoomId: z.number().int().positive().optional(), reason: z.enum(["spam", "harassment", "unsafe", "copyright", "other"]), details: z.string().trim().max(500).optional() })).mutation(({ ctx, input }) => createModerationReport({ ...input, reporterId: ctx.user.id })),
    block: protectedProcedure.input(z.object({ userId: z.number().int().positive() })).mutation(({ ctx, input }) => {
      if (ctx.user.id === input.userId) throw new TRPCError({ code: "BAD_REQUEST", message: "A própria conta não pode ser bloqueada." });
      return blockUser({ blockerId: ctx.user.id, blockedUserId: input.userId });
    }),
  }),
  wallet: router({
    me: protectedProcedure.query(({ ctx }) => getWalletByUserId(ctx.user.id)),
    ledger: protectedProcedure.query(({ ctx }) => getWalletLedger(ctx.user.id)),
    supportCreator: protectedProcedure.input(z.object({ creatorUserId: z.number().int().positive(), videoId: z.number().int().positive().optional(), kashMilli: kashAmountSchema })).mutation(async ({ ctx, input }) => {
      if (ctx.user.id === input.creatorUserId) throw new TRPCError({ code: "BAD_REQUEST", message: "Não é possível apoiar a própria conta." });
      return supportCreator({ ...input, senderUserId: ctx.user.id });
    }),
    createCheckout: protectedProcedure.input(z.object({ packageId: z.enum(["starter", "supporter", "creator"]) })).mutation(async ({ ctx, input }) => {
      const origin = ctx.req.headers.origin;
      if (!origin) throw new TRPCError({ code: "BAD_REQUEST", message: "A origem da solicitação é obrigatória." });
      const session = await createKashCheckoutSession({ packageId: input.packageId, userId: ctx.user.id, userName: ctx.user.name, userEmail: ctx.user.email, origin });
      return { checkoutUrl: session.url };
    }),
    createCommunitySubscription: protectedProcedure.input(z.object({ communityId: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
      const record = await getCommunityById(input.communityId);
      if (!record) throw new TRPCError({ code: "NOT_FOUND", message: "Comunidade não encontrada." });
      const origin = ctx.req.headers.origin;
      if (!origin) throw new TRPCError({ code: "BAD_REQUEST", message: "A origem da solicitação é obrigatória." });
      const session = await createCommunitySubscriptionCheckoutSession({ communityId: record.community.id, communityName: record.community.name, monthlyPriceCents: record.community.monthlyPriceCents, creatorId: record.community.creatorId, userId: ctx.user.id, userName: ctx.user.name, userEmail: ctx.user.email, origin });
      return { checkoutUrl: session.url };
    }),
    requestPayout: protectedProcedure.input(z.object({ brlCents: z.number().int().min(5_000) })).mutation(async ({ ctx, input }) => {
      const reserved = await requestCreatorPayout({ userId: ctx.user.id, ...input });
      try { const transfer = await sendCreatorTransfer({ stripeAccountId: reserved.stripeAccountId, brlCents: input.brlCents, transactionId: reserved.transactionId }); await markPayoutSubmitted({ transactionId: reserved.transactionId, providerTransferId: transfer.id }); return { status: "submitted" as const, transferId: transfer.id }; } catch (error) { await failPayoutRequest({ transactionId: reserved.transactionId }); throw error; }
    }),
    beginCreatorOnboarding: protectedProcedure.mutation(async ({ ctx }) => {
      const wallet = await getWalletByUserId(ctx.user.id);
      const origin = ctx.req.headers.origin;
      if (!origin) throw new TRPCError({ code: "BAD_REQUEST", message: "A origem da solicitação é obrigatória." });
      return createCreatorOnboardingLink({ userId: ctx.user.id, stripeAccountId: wallet?.stripeAccountId, origin });
    }),
  }),
  media: router({
    upload: protectedProcedure.input(mediaInput).mutation(async ({ ctx, input }) => {
      const bytes = Buffer.from(input.base64, "base64");
      validateMedia(input.kind, input.mimeType, bytes);
      const extension = input.mimeType.split("/")[1]?.replace("jpeg", "jpg") ?? "bin";
      const scope = input.kind === "video" ? "videos" : `${input.kind}s`;
      const stored = await storagePut(`users/${ctx.user.id}/${scope}/${nanoid()}.${extension}`, bytes, input.mimeType);
      return { key: stored.key, url: stored.url, mimeType: input.mimeType };
    }),
  }),
});
