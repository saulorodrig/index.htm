import { describe, expect, it } from "vitest";
import {
  MINIMUM_VIEW_RETENTION_MS,
  brlCentsToKashMilli,
  calculateKashSplit,
  isValidViewRetention,
  kashMilliToBrlCents,
} from "../shared/kash";

describe("regras financeiras do Kash", () => {
  it("converte R$ 1,00 em 10 Kash sem perda de precisão", () => {
    expect(brlCentsToKashMilli(100)).toBe(10_000);
    expect(kashMilliToBrlCents(10_000)).toBe(100);
  });

  it("separa um apoio em 85% para o criador e 15% para a plataforma", () => {
    expect(calculateKashSplit(40_000)).toEqual({
      creatorKashMilli: 34_000,
      platformKashMilli: 6_000,
    });
  });

  it("aceita uma visualização somente depois de três segundos", () => {
    expect(isValidViewRetention(MINIMUM_VIEW_RETENTION_MS - 1)).toBe(false);
    expect(isValidViewRetention(MINIMUM_VIEW_RETENTION_MS)).toBe(true);
  });
});
