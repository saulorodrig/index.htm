import { describe, expect, it } from "vitest";
import { assertCreatorSupport, assertPayoutEligibility, shouldCreditPaymentIntent } from "./kash-flow";

describe("fluxos críticos de Kash", () => {
  const eligibleWallet = { brlBalanceCents: 7_500, kycStatus: "verified" as const, payoutsEnabled: 1, stripeAccountId: "acct_kas" };

  it("aprova apoio e saque que atendem às regras financeiras", () => {
    expect(() => assertCreatorSupport({ senderUserId: 1, creatorUserId: 2, senderKashMilli: 40_000, kashMilli: 40_000 })).not.toThrow();
    expect(() => assertPayoutEligibility(eligibleWallet, 5_000)).not.toThrow();
  });

  it("bloqueia saldo insuficiente e saque sem elegibilidade", () => {
    expect(() => assertCreatorSupport({ senderUserId: 1, creatorUserId: 2, senderKashMilli: 999, kashMilli: 1_000 })).toThrow("Saldo Kash insuficiente");
    expect(() => assertPayoutEligibility({ ...eligibleWallet, kycStatus: "pending" }, 5_000)).toThrow("KYC");
  });

  it("não permite novo crédito quando o payment intent já foi processado", () => {
    expect(shouldCreditPaymentIntent(undefined)).toBe(true);
    expect(shouldCreditPaymentIntent(42)).toBe(false);
  });
});
