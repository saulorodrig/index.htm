import type { Express, Request, Response } from "express";
import express from "express";
import Stripe from "stripe";
import { getKashPackage, type KashPackageId } from "./kash-products";
import { creditPurchasedKash, storeStripeConnectedAccount, syncStripeConnectedAccount } from "./db";

const stripe = process.env.STRIPE_SECRET_KEY
  ? new Stripe(process.env.STRIPE_SECRET_KEY)
  : null;

export async function createKashCheckoutSession(input: {
  packageId: KashPackageId;
  userId: number;
  userName?: string | null;
  userEmail?: string | null;
  origin: string;
}) {
  if (!stripe) {
    throw new Error("A integração de pagamento não está configurada neste ambiente.");
  }

  const product = getKashPackage(input.packageId);
  return stripe.checkout.sessions.create({
    mode: "payment",
    allow_promotion_codes: true,
    customer_email: input.userEmail ?? undefined,
    client_reference_id: input.userId.toString(),
    line_items: [
      {
        price_data: {
          currency: "brl",
          product_data: {
            name: product.label,
            description: `${product.kashMilli / 1_000} Kash para apoiar criadores no kas`,
          },
          unit_amount: product.brlCents,
        },
        quantity: 1,
      },
    ],
    metadata: {
      user_id: input.userId.toString(),
      customer_email: input.userEmail ?? "",
      customer_name: input.userName ?? "",
      package_id: product.id,
      kash_milli: product.kashMilli.toString(),
    },
    success_url: `${input.origin}/?checkout=success`,
    cancel_url: `${input.origin}/?checkout=cancelled`,
  });
}

export async function createCreatorOnboardingLink(input: { userId: number; stripeAccountId?: string | null; origin: string }) {
  if (!stripe) throw new Error("A integração de pagamento não está configurada neste ambiente.");
  let accountId = input.stripeAccountId ?? undefined;
  if (!accountId) {
    const account = await stripe.accounts.create({
      type: "express",
      capabilities: { transfers: { requested: true } },
      metadata: { user_id: input.userId.toString() },
    });
    accountId = account.id;
    await storeStripeConnectedAccount({ userId: input.userId, stripeAccountId: accountId });
  }
  const link = await stripe.accountLinks.create({
    account: accountId,
    refresh_url: `${input.origin}/?connect=refresh`,
    return_url: `${input.origin}/?connect=complete`,
    type: "account_onboarding",
  });
  return { onboardingUrl: link.url, stripeAccountId: accountId };
}

export async function sendCreatorTransfer(input: { stripeAccountId: string; brlCents: number; transactionId: number }) {
  if (!stripe) throw new Error("A integração de pagamento não está configurada neste ambiente.");
  return stripe.transfers.create({
    amount: input.brlCents,
    currency: "brl",
    destination: input.stripeAccountId,
    metadata: { kas_transaction_id: input.transactionId.toString(), purpose: "creator_payout" },
  });
}

export function registerStripeWebhook(app: Express) {
  app.post(
    "/api/stripe/webhook",
    express.raw({ type: "application/json" }),
    async (req: Request, res: Response) => {
      if (!stripe || !process.env.STRIPE_WEBHOOK_SECRET) {
        return res.status(503).json({ error: "Integração de pagamento indisponível." });
      }

      const signature = req.headers["stripe-signature"];
      if (!signature || Array.isArray(signature)) {
        return res.status(400).json({ error: "Assinatura Stripe ausente." });
      }

      let event: Stripe.Event;
      try {
        event = stripe.webhooks.constructEvent(req.body, signature, process.env.STRIPE_WEBHOOK_SECRET);
      } catch (error) {
        return res.status(400).json({ error: "Assinatura Stripe inválida." });
      }

      if (event.id.startsWith("evt_test_")) {
        return res.json({ verified: true });
      }

      if (event.type === "checkout.session.completed") {
        const session = event.data.object as Stripe.Checkout.Session;
        const userId = Number(session.metadata?.user_id);
        const kashMilli = Number(session.metadata?.kash_milli);
        const paymentIntentId = typeof session.payment_intent === "string" ? session.payment_intent : session.payment_intent?.id;

        if (Number.isInteger(userId) && Number.isInteger(kashMilli) && kashMilli > 0 && paymentIntentId) {
          await creditPurchasedKash({
            userId,
            kashMilli,
            brlCents: session.amount_total ?? 0,
            stripePaymentIntentId: paymentIntentId,
          });
        }
      }

      if (event.type === "account.updated") {
        const account = event.data.object as Stripe.Account;
        await syncStripeConnectedAccount({
          stripeAccountId: account.id,
          payoutsEnabled: account.payouts_enabled,
          requirementsPending: Boolean(account.requirements?.currently_due?.length),
        });
      }

      return res.json({ received: true });
    },
  );
}


export async function createCommunitySubscriptionCheckoutSession(input: { communityId: number; communityName: string; monthlyPriceCents: number; creatorId: number; userId: number; userName?: string | null; userEmail?: string | null; origin: string }) {
  if (!stripe) throw new Error("A integração de pagamento não está configurada neste ambiente.");
  if (input.monthlyPriceCents < 100) throw new Error("O plano da comunidade precisa ter um valor mínimo de R$ 1,00.");
  return stripe.checkout.sessions.create({
    mode: "subscription",
    allow_promotion_codes: true,
    customer_email: input.userEmail ?? undefined,
    client_reference_id: input.userId.toString(),
    line_items: [{ price_data: { currency: "brl", product_data: { name: `Comunidade ${input.communityName}`, description: "Acesso recorrente à comunidade de criadores no KAS" }, unit_amount: input.monthlyPriceCents, recurring: { interval: "month" } }, quantity: 1 }],
    metadata: { user_id: input.userId.toString(), community_id: input.communityId.toString(), creator_id: input.creatorId.toString(), customer_email: input.userEmail ?? "", customer_name: input.userName ?? "", purpose: "community_subscription" },
    subscription_data: { metadata: { user_id: input.userId.toString(), community_id: input.communityId.toString(), creator_id: input.creatorId.toString() } },
    success_url: `${input.origin}/?subscription=success`,
    cancel_url: `${input.origin}/?subscription=cancelled`,
  });
}

export async function createExclusiveCheckoutSession(input: { contentId: number; title: string; priceCents: number; creatorId: number; userId: number; userName?: string | null; userEmail?: string | null; origin: string }) {
  if (!stripe) throw new Error("A integração de pagamento não está configurada neste ambiente.");
  if (input.priceCents < 100) throw new Error("O conteúdo exclusivo precisa ter um valor mínimo de R$ 1,00.");
  return stripe.checkout.sessions.create({
    mode: "payment",
    allow_promotion_codes: true,
    customer_email: input.userEmail ?? undefined,
    client_reference_id: input.userId.toString(),
    line_items: [{ price_data: { currency: "brl", product_data: { name: input.title, description: "Conteúdo exclusivo de um criador KAS" }, unit_amount: input.priceCents }, quantity: 1 }],
    metadata: { user_id: input.userId.toString(), content_id: input.contentId.toString(), creator_id: input.creatorId.toString(), customer_email: input.userEmail ?? "", customer_name: input.userName ?? "", purpose: "exclusive_unlock" },
    success_url: `${input.origin}/?exclusive=success&content=${input.contentId}`,
    cancel_url: `${input.origin}/?exclusive=cancelled&content=${input.contentId}`,
  });
}
