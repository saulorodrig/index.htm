import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import { trpc } from "@/lib/trpc";
import { KAS_GIFTS } from "@shared/gifts";
import {
  Activity,
  ArrowUpRight,
  BarChart3,
  Bell,
  BookOpen,
  CalendarDays,
  Check,
  ChevronRight,
  CircleDollarSign,
  Clapperboard,
  Compass,
  Copy,
  Crown,
  Eye,
  Flame,
  Gift,
  Heart,
  House,
  Layers3,
  LockKeyhole,
  MessageCircle,
  MoreHorizontal,
  Pause,
  Play,
  Plus,
  Search,
  Send,
  Settings2,
  ShieldCheck,
  Sparkles,
  Ticket,
  TrendingUp,
  UserRound,
  UsersRound,
  Video,
  Volume2,
  VolumeX,
  WalletCards,
  X,
  Zap,
} from "lucide-react";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { toast } from "sonner";

const POSTER_URL = "/manus-storage/kas-neon-creator_d60cf531.jpg";
const DEMO_VIDEO_URL = "https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4";

type Tab = "feed" | "live" | "communities" | "studio" | "wallet";

type FeedItem = {
  id: number;
  title: string;
  caption: string;
  videoUrl: string;
  thumbnailUrl: string;
  totalViews: number;
  totalLikes: number;
  creator: { id: number; name: string; handle: string; avatarUrl: string; bio: string; followers: string };
};

const DEMO_VIDEOS: FeedItem[] = [
  {
    id: 1,
    title: "Midnight bloom",
    caption: "Um minuto para desacelerar e deixar a noite falar. #visual #mood",
    videoUrl: DEMO_VIDEO_URL,
    thumbnailUrl: POSTER_URL,
    totalViews: 128400,
    totalLikes: 18400,
    creator: { id: 101, name: "Luna Kyo", handle: "@lunakyo", avatarUrl: POSTER_URL, bio: "Direção criativa, luz e movimento.", followers: "248 mil" },
  },
  {
    id: 2,
    title: "Purple frequency",
    caption: "Quando a cidade vira textura e cada luz encontra um ritmo. #nightshift",
    videoUrl: DEMO_VIDEO_URL,
    thumbnailUrl: POSTER_URL,
    totalViews: 89300,
    totalLikes: 9600,
    creator: { id: 102, name: "Kai Avenue", handle: "@kaiavenue", avatarUrl: POSTER_URL, bio: "Filmes breves para horas longas.", followers: "96,4 mil" },
  },
  {
    id: 3,
    title: "Signal 03",
    caption: "Estudo de cor, ruído e presença. Salve para ver de novo depois.",
    videoUrl: DEMO_VIDEO_URL,
    thumbnailUrl: POSTER_URL,
    totalViews: 54700,
    totalLikes: 7200,
    creator: { id: 103, name: "Noah Rami", handle: "@noahrami", avatarUrl: POSTER_URL, bio: "Cenas digitais e objetos imaginários.", followers: "71,8 mil" },
  },
];

const LIVE_ROOMS = [
  { id: 1, creator: "Maya Sol", handle: "@mayasol", title: "Estúdio aberto: construindo uma faixa do zero", category: "Música", viewers: "2,8 mil", goal: 72, accent: "#d9ff63", avatar: POSTER_URL },
  { id: 2, creator: "Ravi Nox", handle: "@ravinox", title: "Bastidores do clipe Neon da Serra", category: "Arte & cultura", viewers: "1,2 mil", goal: 48, accent: "#b8a5ff", avatar: POSTER_URL },
  { id: 3, creator: "Júlia Vento", handle: "@juliavento", title: "Pergunte tudo sobre viver de criação", category: "Criadores", viewers: "864", goal: 31, accent: "#ffb870", avatar: POSTER_URL },
];

const COMMUNITY_ROOMS = [
  { id: 1, name: "Clube da Lua", handle: "@clubedalua", creator: "Luna Kyo", members: "18,4 mil", price: "R$ 9,90/mês", level: "Círculo", description: "Um espaço para quem cria devagar, compartilha referências e chega mais perto do processo.", accent: "lime" },
  { id: 2, name: "Sinal Aberto", handle: "@sinalaberto", creator: "Noah Rami", members: "8,7 mil", price: "R$ 6,90/mês", level: "Inner", description: "Feedbacks honestos, desafios colaborativos e encontros para tirar ideias do papel.", accent: "violet" },
  { id: 3, name: "Rua 808", handle: "@rua808", creator: "Kai Avenue", members: "5,2 mil", price: "R$ 12,90/mês", level: "Círculo", description: "Música, noite e cultura urbana em uma comunidade feita de troca real.", accent: "orange" },
];

const NAV_ITEMS = [
  { id: "feed" as Tab, label: "Descobrir", icon: House },
  { id: "live" as Tab, label: "Ao vivo", icon: Activity, badge: "12" },
  { id: "communities" as Tab, label: "Comunidades", icon: UsersRound },
  { id: "studio" as Tab, label: "Meu estúdio", icon: BarChart3 },
  { id: "wallet" as Tab, label: "Carteira", icon: WalletCards },
];

const CATEGORY_ITEMS = ["Tudo", "Música", "Arte & cultura", "Games", "Lifestyle", "Comédia", "#visual"];
const chartBars = [32, 44, 39, 56, 48, 72, 65, 83, 78, 92, 88, 100];

const compactNumber = (value: number) => new Intl.NumberFormat("pt-BR", { notation: "compact", maximumFractionDigits: 1 }).format(value);
const formatKash = (value: number) => new Intl.NumberFormat("pt-BR", { maximumFractionDigits: 0 }).format(value / 1_000);
const formatBRL = (cents: number) => new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(cents / 100);
const fileToBase64 = (file: File) => new Promise<string>((resolve, reject) => { const reader = new FileReader(); reader.onload = () => resolve(String(reader.result).split(",")[1] ?? ""); reader.onerror = () => reject(new Error("Não foi possível ler o arquivo.")); reader.readAsDataURL(file); });

function BrandMark() {
  return <div className="brand-mark" aria-hidden="true"><span /><span /><span /></div>;
}

function Avatar({ src = POSTER_URL, alt = "", className = "" }: { src?: string; alt?: string; className?: string }) {
  return <img src={src} alt={alt} className={`avatar ${className}`} />;
}

function IconButton({ label, children, onClick, active = false }: { label: string; children: React.ReactNode; onClick?: () => void; active?: boolean }) {
  return <button aria-label={label} title={label} onClick={onClick} className={`icon-button ${active ? "is-active" : ""}`}>{children}</button>;
}

function SectionHeading({ eyebrow, title, description, action }: { eyebrow?: string; title: string; description?: string; action?: React.ReactNode }) {
  return <div className="section-heading"><div>{eyebrow && <p className="eyebrow">{eyebrow}</p>}<h1>{title}</h1>{description && <p className="section-description">{description}</p>}</div>{action}</div>;
}

function MetricCard({ label, value, delta, icon: Icon, tone = "lime" }: { label: string; value: string; delta: string; icon: typeof TrendingUp; tone?: string }) {
  return <div className={`metric-card tone-${tone}`}><div className="metric-card-top"><span>{label}</span><Icon className="metric-icon" size={17} /></div><strong>{value}</strong><small><TrendingUp size={13} /> {delta}</small></div>;
}

function FeedView({
  feed,
  currentIndex,
  setCurrentIndex,
  currentVideo,
  isPlaying,
  setIsPlaying,
  isMuted,
  setIsMuted,
  liked,
  onLike,
  onComment,
  onSupport,
  onShare,
  onFollow,
  onViewProfile,
  onHashtagSelect,
  shared,
  likePulse,
  supportPulse,
  categories,
  setCategories,
  onLoadMore,
}: {
  feed: FeedItem[];
  currentIndex: number;
  setCurrentIndex: React.Dispatch<React.SetStateAction<number>>;
  currentVideo: FeedItem;
  isPlaying: boolean;
  setIsPlaying: React.Dispatch<React.SetStateAction<boolean>>;
  isMuted: boolean;
  setIsMuted: React.Dispatch<React.SetStateAction<boolean>>;
  liked: number[];
  onLike: () => void;
  onComment: () => void;
  onSupport: () => void;
  onShare: () => void;
  onFollow: () => void;
  onViewProfile: () => void;
  onHashtagSelect: (value: string) => void;
  shared: boolean;
  likePulse: boolean;
  supportPulse: boolean;
  categories: string;
  setCategories: (value: string) => void;
  onLoadMore: () => void;
}) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const loadMoreRef = useRef<HTMLDivElement>(null);
  useEffect(() => { const node = loadMoreRef.current; if (!node) return; const observer = new IntersectionObserver(entries => { if (entries[0]?.isIntersecting) onLoadMore(); }, { rootMargin: "600px" }); observer.observe(node); return () => observer.disconnect(); }, [onLoadMore]);
  useEffect(() => { const video = videoRef.current; if (!video) return; video.muted = isMuted; if (isPlaying) video.play().catch(() => undefined); else video.pause(); }, [currentVideo.id, isMuted, isPlaying]);
  const go = (direction: 1 | -1) => setCurrentIndex(index => (index + direction + feed.length) % feed.length);
  const isLiked = liked.includes(currentVideo.id);
  return <div className="feed-layout">
    <section className="feed-main">
      <SectionHeading eyebrow="Descoberta / 01" title="Descobrir" description="Uma curadoria viva do que está acontecendo agora." action={<button className="ghost-button" onClick={() => toast("Seu feed está aprendendo", { description: "Salve, curta e siga para calibrar sua próxima descoberta." })}><Sparkles size={15} /> Afinar meu feed</button>} />
      <div className="category-scroll">{CATEGORY_ITEMS.map(category => <button key={category} onClick={() => { setCategories(category); if (category.startsWith("#")) onHashtagSelect(category); }} className={categories === category ? "category-chip active" : "category-chip"}>{category}</button>)}</div>
      <div className="video-stage-wrap">
        <div className="video-stage" style={{ backgroundImage: `url(${currentVideo.thumbnailUrl})` }}>
          <video ref={videoRef} className="video-element" src={currentVideo.videoUrl} poster={currentVideo.thumbnailUrl} muted={isMuted} loop playsInline autoPlay onClick={() => setIsPlaying(value => !value)} />
          <div className="video-vignette" />
          <div className="stage-topline"><span className="live-pip" /> <span>{categories === "Tudo" ? "Agora na sua órbita" : categories}</span><span className="stage-counter">{String(currentIndex + 1).padStart(2, "0")} / {String(feed.length).padStart(2, "0")}</span></div>
          <button aria-label={isPlaying ? "Pausar vídeo" : "Reproduzir vídeo"} className={`play-button ${isPlaying ? "is-playing" : ""}`} onClick={() => setIsPlaying(value => !value)}>{isPlaying ? <Pause size={20} fill="currentColor" /> : <Play size={20} fill="currentColor" />}</button>
          <div className="video-copy"><div className="creator-line"><Avatar src={currentVideo.creator.avatarUrl} alt={currentVideo.creator.name} /><span className="creator-handle">{currentVideo.creator.handle}</span><button className="mini-follow" onClick={onFollow}>Seguir</button></div><h2>{currentVideo.title}</h2><p>{currentVideo.caption}</p><div className="video-meta"><span><Eye size={14} /> {compactNumber(currentVideo.totalViews)} views</span><span>•</span><span>som original</span></div></div>
          <div className="video-actions">{likePulse && <div className="heart-burst" aria-live="polite"><Heart size={14} fill="currentColor" /><Heart size={17} fill="currentColor" /><Heart size={12} fill="currentColor" /></div>}<button onClick={onLike} className={isLiked ? `video-action active ${likePulse ? "pulse-now" : ""}` : "video-action"}><span><Heart size={21} fill={isLiked ? "currentColor" : "none"} /></span><small>{compactNumber(currentVideo.totalLikes + (isLiked ? 1 : 0))}</small></button><button onClick={onComment} className="video-action"><span><MessageCircle size={21} /></span><small>1,2k</small></button><button onClick={onSupport} className={`video-action gift-action ${supportPulse ? "pulse-now" : ""}`}><span><Gift size={21} /></span><small>Apoiar</small></button><button onClick={onShare} className={shared ? "video-action active" : "video-action"}><span><ShareIcon copied={shared} /></span><small>{shared ? "Copiado" : "Enviar"}</small></button><IconButton label={isMuted ? "Ativar som" : "Silenciar"} onClick={() => setIsMuted(value => !value)}><span className="video-action-icon">{isMuted ? <VolumeX size={18} /> : <Volume2 size={18} />}</span></IconButton></div>
        </div>
        <div className="stage-navigation"><button onClick={() => go(-1)}><ChevronRight size={16} className="rotate-180" /> anterior</button><div className="stage-dots">{feed.map((item, index) => <button key={item.id} aria-label={`Ver vídeo ${index + 1}`} onClick={() => setCurrentIndex(index)} className={index === currentIndex ? "active" : ""} />)}</div><button onClick={() => go(1)}>próximo <ChevronRight size={16} /></button></div><div ref={loadMoreRef} className="feed-load-sentinel" aria-hidden="true" />
      </div>
    </section>
    <aside className="right-rail feed-rail"><div className="rail-card creator-focus-card"><div className="rail-label"><span>criador em foco</span><MoreHorizontal size={15} /></div><div className="focus-profile"><Avatar src={currentVideo.creator.avatarUrl} className="focus-avatar" /><div><strong>{currentVideo.creator.name}</strong><span>{currentVideo.creator.handle}</span></div><span className="verified-dot"><Check size={12} /></span></div><p>{currentVideo.creator.bio}</p><div className="focus-stats"><div><strong>{currentVideo.creator.followers}</strong><span>seguidores</span></div><div><strong>4,8%</strong><span>engajamento</span></div></div><button className="outline-button full-width" onClick={onViewProfile}>Ver perfil <ArrowUpRight size={15} /></button></div><div className="rail-card live-teaser"><div className="rail-label"><span><span className="live-pip" /> em destaque agora</span><span className="accent-label">ao vivo</span></div><div className="live-teaser-visual"><Avatar src={POSTER_URL} className="live-teaser-avatar" /><div><strong>Ritual de criação</strong><span>@mayasol · 2,8 mil assistindo</span></div></div><div className="goal-line"><span>meta da sala</span><strong>72%</strong></div><div className="progress-track"><span style={{ width: "72%" }} /></div><button className="solid-button full-width" onClick={() => toast("Abrindo sala ao vivo", { description: "A sala de Maya Sol está conectando você à transmissão." })}>Entrar na sala <ArrowUpRight size={15} /></button></div><div className="rail-card safety-note"><ShieldCheck size={18} /><div><strong>Espaço com cuidado</strong><p>Regras claras, moderação ativa e ferramentas para você controlar sua experiência.</p></div></div></aside>
  </div>;
}

function ShareIcon({ copied }: { copied: boolean }) { return copied ? <Check size={21} /> : <Send size={20} />; }

function LiveView({ onSupport }: { onSupport: () => void }) {
  const [selected, setSelected] = useState(0);
  const [message, setMessage] = useState("");
  const [chat, setChat] = useState(["A textura desse synth ficou linda.", "Maya, mostra o patch do refrão!", "Cheguei agora e já estou preso nessa ideia."]);
  const [activeEffect, setActiveEffect] = useState("none");
  const room = LIVE_ROOMS[selected];
  const { isAuthenticated } = useAuth();
  const liveMessagesQuery = trpc.kas.live.messages.useQuery({ roomId: room.id }, { refetchInterval: 5_000 });
  const sendLiveMessageMutation = trpc.kas.live.sendMessage.useMutation({ onSuccess: () => liveMessagesQuery.refetch(), onError: error => toast.error(error.message) });
  const visibleChat = liveMessagesQuery.data?.length ? liveMessagesQuery.data.slice().reverse().map(item => item.message.body) : chat;
  const sendMessage = () => { const body = message.trim(); if (!body) return; setChat(items => [...items, body]); setMessage(""); if (isAuthenticated) sendLiveMessageMutation.mutate({ roomId: room.id, body }); };
  return <div className="page-layout"><SectionHeading eyebrow="Presença / 02" title="Ao vivo" description="Salas com contexto, intenção e espaço para a conversa acontecer." action={<button className="solid-button" onClick={() => toast("Acesso de criador", { description: "Crie sua próxima sala pela central do criador." })}><Plus size={16} /> Criar uma live</button>} /><div className="live-layout"><div className="live-room-panel"><div className={`live-room-visual effect-${activeEffect}`} style={{ backgroundImage: `url(${POSTER_URL})` }}><div className="live-room-overlay" />{activeEffect !== "none" && <div className="live-effect-overlay" aria-live="polite"><div className="live-effect-orbit"><Crown size={18} /></div><span>{KAS_GIFTS.find(gift => gift.effectKey === activeEffect)?.label}</span></div>}<div className="room-live-tag"><span className="live-pip" /> AO VIVO</div><div className="room-viewers"><Eye size={14} /> {room.viewers}</div><div className="live-room-title"><span>{room.category}</span><h2>{room.title}</h2><div className="creator-line"><Avatar src={room.avatar} /><strong>{room.creator}</strong><span>{room.handle}</span></div></div></div><div className="live-effect-picker"><div><span className="eyebrow">efeitos de apoio</span><strong>Escolha o sinal da sala</strong></div><div className="live-effect-options">{KAS_GIFTS.slice(0, 3).map(gift => <button key={gift.slug} onClick={() => { setActiveEffect(gift.effectKey); onSupport(); }} className={activeEffect === gift.effectKey ? "active" : ""}><Gift size={13} /><span>{gift.label}</span><b>{gift.costKash}</b></button>)}</div></div><div className="goal-card"><div className="goal-line"><span>meta coletiva · {room.goal}% completa</span><strong>1.440 / 2.000 Kash</strong></div><div className="progress-track"><span style={{ width: `${room.goal}%`, background: room.accent }} /></div><div className="goal-bottom"><span><Flame size={14} /> 86 pessoas apoiaram esta sala</span><button onClick={onSupport}><Gift size={14} /> Enviar presente</button></div></div><div className="live-room-list">{LIVE_ROOMS.map((item, index) => <button key={item.id} onClick={() => setSelected(index)} className={selected === index ? "live-list-item selected" : "live-list-item"}><Avatar src={item.avatar} /><div><strong>{item.title}</strong><span>{item.creator} · {item.viewers}</span></div><span className="list-live-pip" style={{ background: item.accent }} /></button>)}</div></div><div className="chat-panel"><div className="chat-header"><div><span className="eyebrow">conversa ao vivo</span><strong>Chat da sala</strong></div><div className="chat-status"><span className="status-dot" /> conectado</div></div><div className="pinned-message"><Crown size={14} /><span><strong>Meta da sala</strong> — ao alcançar 2.000 Kash, Maya libera o sample exclusivo para a comunidade.</span></div><div className="chat-messages">{visibleChat.map((item, index) => <div className="chat-message" key={`${item}-${index}`}><Avatar src={POSTER_URL} /><div><span className="chat-author">{["Lia S.", "andre.wav", "cami" ][index % 3]} <small>{index === 0 ? "apoiador" : ""}</small></span><p>{item}</p></div></div>)}</div><div className="chat-composer"><input value={message} onChange={event => setMessage(event.target.value)} onKeyDown={event => { if (event.key === "Enter") sendMessage(); }} placeholder="Diga algo para a sala..." aria-label="Mensagem do chat" /><button aria-label="Enviar mensagem" onClick={sendMessage}><Send size={17} /></button></div><div className="chat-footer"><span><ShieldCheck size={13} /> comunidade moderada</span><button onClick={() => toast("Regras da sala", { description: "Sem assédio, spam ou exposição de dados pessoais." })}>regras</button></div></div></div></div>;
}

function CommunitiesView({ onSubscribe, onUnlockExclusive }: { onSubscribe: (community: typeof COMMUNITY_ROOMS[number]) => void; onUnlockExclusive: () => void }) {
  const [selected, setSelected] = useState(0);
  const community = COMMUNITY_ROOMS[selected];
  return <div className="page-layout"><SectionHeading eyebrow="Pertencimento / 03" title="Comunidades" description="Fãs não são audiência passiva. São parte do processo." action={<button className="ghost-button" onClick={() => toast("Encontre sua tribo", { description: "Busque por tema, criador ou missão para entrar em uma comunidade." })}><Search size={15} /> Explorar temas</button>} /><div className="community-layout"><div className="community-list">{COMMUNITY_ROOMS.map((item, index) => <button key={item.id} onClick={() => setSelected(index)} className={selected === index ? `community-card selected accent-${item.accent}` : `community-card accent-${item.accent}`}><div className="community-card-top"><span className="community-symbol"><Layers3 size={17} /></span><span className="community-level"><Crown size={12} /> {item.level}</span></div><h3>{item.name}</h3><span className="community-handle">{item.handle} · {item.members} membros</span><p>{item.description}</p><div className="community-card-bottom"><span>{item.price}</span><ChevronRight size={16} /></div></button>)}</div><div className="community-detail"><div className="detail-cover"><div className="cover-glow" /><div className="detail-cover-content"><span className="eyebrow">comunidade de {community.creator}</span><h2>{community.name}</h2><p>{community.description}</p><div className="detail-members"><Avatar src={POSTER_URL} /><Avatar src={POSTER_URL} /><Avatar src={POSTER_URL} /><span>+ {community.members} pessoas criando junto</span></div></div></div><div className="detail-body"><div className="detail-tabs"><button className="active">Visão geral</button><button onClick={() => toast("Mural em breve")}>Mural</button><button onClick={() => toast("Calendário em breve")}>Agenda</button><button onClick={() => toast("Conteúdos exclusivos em breve")}>Exclusivos</button></div><div className="mission-card"><div className="mission-icon"><Zap size={17} /></div><div className="mission-copy"><span className="eyebrow">missão colaborativa · termina em 3 dias</span><h3>Fazer a luz circular</h3><p>Compartilhe uma referência de luz e ajude a comunidade a montar o próximo moodboard.</p><div className="progress-track"><span style={{ width: "68%" }} /></div><small>68% · 340 de 500 referências</small></div><button className="outline-button" onClick={() => toast.success("Referência registrada", { description: "Sua contribuição entrou na missão da comunidade." })}>Participar</button></div><div className="exclusive-card"><div className="exclusive-card-icon"><LockKeyhole size={17} /></div><div><span className="eyebrow">drop exclusivo · para membros</span><h3>Notas de processo: a luz antes da cena</h3><p>Um vídeo curto e um moodboard da próxima criação, liberados para quem quer ver antes.</p></div><button className="outline-button" onClick={onUnlockExclusive}>Desbloquear · R$ 7,90 <ArrowUpRight size={14} /></button></div><div className="community-columns"><div><span className="eyebrow">próximo encontro</span><div className="schedule-row"><div className="schedule-date"><strong>24</strong><span>JUN</span></div><div><strong>Feedback sem filtro</strong><span>Quarta · 20:30 · sala da comunidade</span></div><CalendarDays size={17} /></div></div><div><span className="eyebrow">ranking saudável</span><div className="ranking-row"><span className="ranking-position">01</span><Avatar src={POSTER_URL} /><div><strong>bia.frames</strong><span>+ 420 pontos de presença</span></div><span className="ranking-badge">Círculo</span></div></div></div><button className="solid-button full-width" onClick={() => onSubscribe(community)}><Sparkles size={16} /> Entrar por {community.price}</button></div></div></div></div>;
}

function StudioView({ onPublish, summary }: { onPublish: () => void; summary?: { totalViews: number; totalLikes: number; publishedPosts: number; estimatedCents: number } }) {
  const totalViews = summary?.totalViews ?? 284600;
  const totalLikes = summary?.totalLikes ?? 24800;
  const engagement = totalViews ? `${((totalLikes / totalViews) * 100).toFixed(1).replace(".", ",")}%` : "0%";
  const estimated = summary ? `R$ ${(summary.estimatedCents / 100).toLocaleString("pt-BR", { minimumFractionDigits: 0, maximumFractionDigits: 0 })}` : "R$ 3.842";
  return <div className="page-layout"><SectionHeading eyebrow="Bastidores / 04" title="Meu estúdio" description="Decisões melhores começam quando você enxerga o seu próprio ritmo." action={<button className="solid-button" onClick={onPublish}><Plus size={16} /> Publicar conteúdo</button>} /><div className="studio-top-grid"><MetricCard label="Alcance total" value={compactNumber(totalViews)} delta={summary ? "atualizado agora" : "+18,4% vs. semana passada"} icon={Eye} /><MetricCard label="Engajamento" value={engagement} delta={summary ? `${totalLikes.toLocaleString("pt-BR")} interações` : "+2,1 pts no período"} icon={Heart} tone="violet" /><MetricCard label="Ganhos estimados" value={estimated} delta={summary ? `${summary.publishedPosts} conteúdos publicados` : "+32,8% este mês"} icon={CircleDollarSign} tone="orange" /><MetricCard label="Sequência ativa" value="6 dias" delta="melhor marca: 9 dias" icon={Flame} tone="pink" /></div><div className="studio-grid"><div className="panel chart-panel"><div className="panel-heading"><div><span className="eyebrow">alcance · últimos 30 dias</span><h3>Seu conteúdo está encontrando novas pessoas</h3></div><span className="select-like"><span className="live-pip" /> atualizado a cada 15s</span></div><div className="chart-area"><div className="chart-y"><span>100k</span><span>75k</span><span>50k</span><span>25k</span><span>0</span></div><div className="chart-bars">{chartBars.map((height, index) => <div className="chart-column" key={index}><span style={{ height: `${height}%` }} /><small>{index % 3 === 0 ? `0${Math.floor(index / 3) + 1}` : ""}</small></div>)}</div></div><div className="chart-footer"><span><span className="legend-dot" /> views</span><span>pico de 38,4k · quinta-feira</span></div></div><div className="panel weekly-panel"><div className="panel-heading"><div><span className="eyebrow">ritual semanal</span><h3>Meta de consistência</h3></div><span className="streak-label"><Flame size={13} /> 6/7 dias</span></div><div className="week-days">{["S", "T", "Q", "Q", "S", "S", "D"].map((day, index) => <div key={`${day}-${index}`} className={index < 6 ? "week-day done" : "week-day"}><span>{day}</span>{index < 6 ? <Check size={13} /> : <span />}</div>)}</div><div className="weekly-quote"><Sparkles size={16} /><p>“O algoritmo gosta de presença. Sua comunidade gosta de verdade.”</p></div><button className="outline-button full-width" onClick={() => toast("Meta ajustada", { description: "Você pode criar metas de views, posts, apoio e engajamento." })}>Ajustar meta <Settings2 size={14} /></button></div></div><div className="panel content-panel"><div className="panel-heading"><div><span className="eyebrow">biblioteca de conteúdo</span><h3>O que você publicou</h3></div><button className="text-button" onClick={() => toast("Biblioteca completa em breve")}>ver tudo <ArrowUpRight size={14} /></button></div><div className="content-table"><div className="content-table-head"><span>conteúdo</span><span>alcance</span><span>ganhos</span><span>status</span></div>{["Midnight bloom", "Processo: luz de recorte", "Carta para o próximo mês"].map((title, index) => <div className="content-row" key={title}><div className="content-title"><div className={`content-thumb thumb-${index}`}><Video size={16} /></div><div><strong>{title}</strong><span>{index === 0 ? "Vídeo curto · há 2 dias" : index === 1 ? "Exclusivo · há 5 dias" : "Post · há 1 semana"}</span></div></div><span>{["128,4 mil", "54,2 mil", "18,9 mil"][index]}</span><span>{["R$ 1.248", "R$ 820", "R$ 164"][index]}</span><span className={index === 1 ? "status-pill premium" : "status-pill"}>{index === 1 ? <><LockKeyhole size={12} /> exclusivo</> : <><Check size={12} /> publicado</>}</span></div>)}</div></div></div>;
}

function WalletView({ walletKash, onBuy, onPayout }: { walletKash: number; onBuy: () => void; onPayout: () => void }) {
  return <div className="page-layout"><SectionHeading eyebrow="Economia / 05" title="Carteira Kash" description="Uma economia para reconhecer o trabalho — com clareza em cada movimento." action={<button className="ghost-button" onClick={() => toast("Como funciona o Kash", { description: "R$ 1,00 equivale a 10 Kash. No apoio, 85% vai para o criador e 15% mantém a plataforma." })}><BookOpen size={15} /> Como funciona</button>} /><div className="wallet-layout"><div className="wallet-balance-card"><div className="wallet-card-shine" /><div className="wallet-card-top"><span className="eyebrow">saldo disponível</span><WalletCards size={20} /></div><strong>{formatKash(walletKash)} <small>Kash</small></strong><span className="wallet-brl">equivalente a R$ {((walletKash / 1000) / 10).toFixed(2).replace(".", ",")}</span><div className="wallet-card-bottom"><span>Carteira principal · protegida</span><ShieldCheck size={15} /></div></div><div className="wallet-side-metrics"><div className="wallet-side-card"><span><TrendingUp size={16} /> ganhos este mês</span><strong>R$ 3.842,60</strong><small>+32,8% contra maio</small></div><div className="wallet-side-card"><span><Gift size={16} /> apoio enviado</span><strong>1.840 Kash</strong><small>para 12 criadores</small></div></div></div><div className="wallet-grid"><div className="panel packages-panel"><div className="panel-heading"><div><span className="eyebrow">recarregar Kash</span><h3>Escolha seu ritmo de apoio</h3></div><span className="secure-label"><ShieldCheck size={13} /> checkout seguro</span></div><div className="package-grid">{[{ name: "Pulso", kash: "500", price: "R$ 50", tag: "para testar" }, { name: "Órbita", kash: "1.200", price: "R$ 120", tag: "mais escolhido" }, { name: "Constelação", kash: "3.000", price: "R$ 300", tag: "para quem apoia" }].map((item, index) => <button className={index === 1 ? "package-card featured" : "package-card"} key={item.name} onClick={onBuy}><span className="package-tag">{item.tag}</span><strong>{item.kash} <small>Kash</small></strong><span>{item.price}</span><em>{item.name} <ArrowUpRight size={13} /></em></button>)}</div><p className="fine-print">Pagamentos processados com segurança. Você pode usar seu Kash em presentes, comunidades e conteúdos exclusivos.</p></div><div className="panel history-panel"><div className="panel-heading"><div><span className="eyebrow">atividade recente</span><h3>Histórico</h3></div><button className="text-button" onClick={() => toast("Histórico completo em breve")}>ver tudo <ArrowUpRight size={14} /></button></div><div className="history-list">{[{ icon: Gift, title: "Apoio para @lunakyo", date: "Hoje · 19:42", value: "− 120 Kash", tone: "negative" }, { icon: CircleDollarSign, title: "Recarga Órbita", date: "14 jun · 09:16", value: "+ 1.200 Kash", tone: "positive" }, { icon: Crown, title: "Clube da Lua", date: "12 jun · 20:30", value: "− 9,90 BRL", tone: "negative" }].map(item => <div className="history-row" key={item.title}><span className="history-icon"><item.icon size={16} /></span><div><strong>{item.title}</strong><span>{item.date}</span></div><b className={item.tone}>{item.value}</b></div>)}</div></div></div><div className="payout-banner"><div><span className="eyebrow">para criadores</span><h3>Seu trabalho pode virar fluxo de renda.</h3><p>Conecte sua conta de recebimento, acompanhe o saldo disponível e solicite saque a partir de R$ 50.</p></div><button className="solid-button" onClick={onPayout}>Configurar recebimento <ArrowUpRight size={15} /></button></div></div>;
}

export default function Home() {
  const { user, isAuthenticated } = useAuth();
  const utils = trpc.useUtils();
  const [feedLimit, setFeedLimit] = useState(10);
  const feedInput = useMemo(() => ({ limit: feedLimit }), [feedLimit]);
  const [tab, setTab] = useState<Tab>("feed");
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(true);
  const [isMuted, setIsMuted] = useState(true);
  const [likedVideoIds, setLikedVideoIds] = useState<number[]>([]);
  const [likePulse, setLikePulse] = useState(false);
  const [supportPulse, setSupportPulse] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [followedCreatorIds, setFollowedCreatorIds] = useState<number[]>([]);
  const [commentOpen, setCommentOpen] = useState(false);
  const [supportOpen, setSupportOpen] = useState(false);
  const [selectedKash, setSelectedKash] = useState(120);
  const [selectedGift, setSelectedGift] = useState("pulse-heart");
  const [walletKashMilli, setWalletKashMilli] = useState(1_280_000);
  const [draftComment, setDraftComment] = useState("");
  const [localComments, setLocalComments] = useState(["A textura está incrível.", "Essa paleta ficou memorável."]);
  const [shared, setShared] = useState(false);
  const [categories, setCategories] = useState("Tudo");
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [publishOpen, setPublishOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const [publishTitle, setPublishTitle] = useState("");
  const [publishDescription, setPublishDescription] = useState("");
  const [publishAccess, setPublishAccess] = useState<"public" | "community" | "paid">("public");
  const [publishPrice, setPublishPrice] = useState(790);
  const [publishVideo, setPublishVideo] = useState<File | null>(null);
  const [publishThumbnail, setPublishThumbnail] = useState<File | null>(null);
  const feedQuery = trpc.kas.feed.list.useQuery(feedInput);
  const walletQuery = trpc.kas.wallet.me.useQuery(undefined, { enabled: isAuthenticated });
  const likeMutation = trpc.kas.feed.toggleLike.useMutation();
  const supportMutation = trpc.kas.wallet.supportCreator.useMutation();
  const giftMutation = trpc.kas.live.sendGift.useMutation();
  const recordViewMutation = trpc.kas.feed.recordView.useMutation();
  const createCommentMutation = trpc.kas.feed.createComment.useMutation();
  const checkoutMutation = trpc.kas.wallet.createCheckout.useMutation();
  const followMutation = trpc.kas.social.toggleFollow.useMutation();
  const mediaUploadMutation = trpc.kas.media.upload.useMutation();
  const publishMutation = trpc.kas.creator.publish.useMutation();
  const subscriptionMutation = trpc.kas.wallet.createCommunitySubscription.useMutation();
  const discoveryQuery = trpc.kas.discover.search.useQuery({ term: searchTerm }, { enabled: false });
  const studioQuery = trpc.kas.creator.studio.useQuery(undefined, { enabled: isAuthenticated, refetchInterval: 15_000 });
  const exclusiveCheckoutMutation = trpc.kas.creator.exclusiveCheckout.useMutation();
  const onboardingMutation = trpc.kas.wallet.beginCreatorOnboarding.useMutation();
  const apiFeed = useMemo<FeedItem[]>(() => (feedQuery.data ?? []).map(({ video, creator }) => ({ id: video.id, title: video.title, caption: video.description ?? "", videoUrl: video.videoUrl, thumbnailUrl: video.thumbnailUrl ?? POSTER_URL, totalViews: video.totalViews, totalLikes: video.totalLikes, creator: { id: creator.id, name: creator.name ?? "Criador KAS", handle: creator.handle ? `@${creator.handle.replace(/^@/, "")}` : "@criador", avatarUrl: creator.avatarUrl ?? POSTER_URL, bio: creator.bio ?? "Criador em destaque no KAS.", followers: compactNumber(creator.followerCount) } })), [feedQuery.data]);
  const baseFeed = apiFeed.length ? apiFeed : DEMO_VIDEOS;
  const feed = useMemo(() => { const normalized = searchTerm.trim().toLowerCase().replace(/^@/, ""); if (!normalized) return baseFeed; return baseFeed.filter(item => [item.title, item.caption, item.creator.name, item.creator.handle].some(value => value.toLowerCase().includes(normalized))); }, [baseFeed, searchTerm]);
  const currentVideo = feed[currentIndex % feed.length] ?? DEMO_VIDEOS[0];
  const isDatabaseVideo = apiFeed.length > 0;
  const commentInput = useMemo(() => ({ videoId: currentVideo.id }), [currentVideo.id]);
  const commentsQuery = trpc.kas.feed.comments.useQuery(commentInput, { enabled: commentOpen && isDatabaseVideo });
  const visibleKashMilli = walletQuery.data?.kashMilliBalance ?? walletKashMilli;
  const displayName = user?.name?.split(" ")[0] ?? "visitante";

  useEffect(() => { setCurrentIndex(previous => Math.min(previous, Math.max(feed.length - 1, 0))); }, [feed.length]);
  useEffect(() => { if (!isDatabaseVideo || feed.length === 0) return; const timeout = window.setTimeout(() => recordViewMutation.mutate({ videoId: currentVideo.id, retainedMs: 3_000 }), 3_000); return () => window.clearTimeout(timeout); }, [currentVideo.id, isDatabaseVideo, recordViewMutation]);
  useEffect(() => { const onKeyDown = (event: KeyboardEvent) => { const target = event.target as HTMLElement | null; if (target?.tagName === "INPUT" || target?.tagName === "TEXTAREA" || commentOpen || supportOpen) return; if (event.key === "ArrowDown") { event.preventDefault(); setCurrentIndex(index => (index + 1) % feed.length); } if (event.key === "ArrowUp") { event.preventDefault(); setCurrentIndex(index => (index - 1 + feed.length) % feed.length); } if (event.key === " ") { event.preventDefault(); setIsPlaying(value => !value); } if (event.key.toLowerCase() === "m") setIsMuted(value => !value); }; window.addEventListener("keydown", onKeyDown); return () => window.removeEventListener("keydown", onKeyDown); }, [commentOpen, feed.length, supportOpen]);

  const loadMoreFeed = useCallback(() => { if ((feedQuery.data?.length ?? 0) >= feedLimit && feedLimit < 20) setFeedLimit(current => Math.min(current + 10, 20)); }, [feedLimit, feedQuery.data?.length]);
  const selectHashtag = (value: string) => { setSearchTerm(value); void discoveryQuery.refetch(); };
  const toggleLike = () => { const wasLiked = likedVideoIds.includes(currentVideo.id); setLikePulse(true); window.setTimeout(() => setLikePulse(false), 520); setLikedVideoIds(items => wasLiked ? items.filter(id => id !== currentVideo.id) : [...items, currentVideo.id]); if (isAuthenticated && isDatabaseVideo) likeMutation.mutate({ videoId: currentVideo.id }, { onSuccess: () => utils.kas.feed.list.invalidate() }); else if (!isAuthenticated) toast("Curtida salva nesta prévia", { description: "Entre na sua conta para sincronizar suas interações." }); };
  const followCreator = () => { const wasFollowed = followedCreatorIds.includes(currentVideo.creator.id); setFollowedCreatorIds(items => wasFollowed ? items.filter(id => id !== currentVideo.creator.id) : [...items, currentVideo.creator.id]); if (isAuthenticated) followMutation.mutate({ userId: currentVideo.creator.id }, { onSuccess: () => toast(wasFollowed ? "Você deixou de seguir" : "Você está seguindo", { description: currentVideo.creator.name }) }); else toast("Siga criadores que fazem sentido para você", { description: "Entre para guardar suas conexões." }); };
  const shareVideo = async () => { try { if (navigator.share) await navigator.share({ title: currentVideo.title, text: currentVideo.caption, url: window.location.href }); else { await navigator.clipboard.writeText(window.location.href); toast.success("Link copiado para a área de transferência."); } setShared(true); window.setTimeout(() => setShared(false), 2_000); } catch { /* cancelamento de compartilhamento */ } };
  const submitComment = () => { const content = draftComment.trim(); if (!content) return; setLocalComments(items => [content, ...items]); setDraftComment(""); toast.success("Comentário adicionado"); if (isAuthenticated && isDatabaseVideo) createCommentMutation.mutate({ videoId: currentVideo.id, content }, { onSuccess: () => commentsQuery.refetch() }); };
  const sendSupport = () => { const gift = KAS_GIFTS.find(item => item.slug === selectedGift) ?? KAS_GIFTS[0]; const kashMilli = gift.costKash * 1_000; setSelectedKash(gift.costKash); setSupportPulse(true); window.setTimeout(() => setSupportPulse(false), 700); if (visibleKashMilli < kashMilli) { toast.error("Saldo Kash insuficiente."); return; } setWalletKashMilli(balance => balance - kashMilli); setSupportOpen(false); toast.success(`${gift.label} enviado para ${currentVideo.creator.name}`, { description: `${gift.costKash * .85} Kash seguem para o criador; efeito ${gift.effectKey} ativado.` }); if (isAuthenticated && isDatabaseVideo) supportMutation.mutate({ creatorUserId: currentVideo.creator.id, videoId: currentVideo.id, kashMilli }, { onError: error => { setWalletKashMilli(balance => balance + kashMilli); toast.error(error.message); }, onSuccess: () => utils.kas.wallet.me.invalidate() }); };
  const buyKash = () => { if (!isAuthenticated) { toast("Entre para recarregar seu Kash", { description: "A compra fica vinculada à carteira da sua conta." }); return; } checkoutMutation.mutate({ packageId: "supporter" }, { onSuccess: ({ checkoutUrl }) => { if (checkoutUrl) { toast("Abrindo checkout seguro", { description: "Você será redirecionado para concluir a recarga." }); window.open(checkoutUrl, "_blank", "noopener,noreferrer"); } }, onError: error => toast.error(error.message) }); };
  const openSubscribe = (community: typeof COMMUNITY_ROOMS[number]) => { if (!isAuthenticated) { toast("Entre para fazer parte da comunidade", { description: `O plano ${community.name} começa em ${community.price}.` }); return; } subscriptionMutation.mutate({ communityId: community.id }, { onSuccess: ({ checkoutUrl }) => { if (checkoutUrl) window.open(checkoutUrl, "_blank", "noopener,noreferrer"); }, onError: error => toast.error(error.message, { description: "A comunidade precisa estar publicada para receber assinaturas." }) }); };
  const openExclusive = () => { if (!isAuthenticated) { toast("Entre para desbloquear o conteúdo", { description: "Conteúdos exclusivos ficam ligados à sua conta." }); return; } exclusiveCheckoutMutation.mutate({ contentId: 1 }, { onSuccess: ({ checkoutUrl }) => { if (checkoutUrl) window.open(checkoutUrl, "_blank", "noopener,noreferrer"); }, onError: error => toast("Conteúdo reservado", { description: error.message.includes("não encontrado") ? "O criador ainda está preparando este drop." : error.message }) }); };
  const openPayout = () => { if (!isAuthenticated) { toast("Entre para configurar recebimentos"); return; } onboardingMutation.mutate(undefined, { onSuccess: ({ onboardingUrl }) => { if (onboardingUrl) window.open(onboardingUrl, "_blank", "noopener,noreferrer"); }, onError: error => toast.error(error.message) }); };
  const openProfile = () => setProfileOpen(true);
  const publish = () => { if (!isAuthenticated) { toast("Entre para publicar", { description: "A central do criador fica disponível após o login." }); return; } setPublishOpen(true); };
  const submitPublish = async () => { if (!publishTitle.trim() || !publishVideo) { toast.error("Adicione um título e um vídeo para publicar."); return; } try { const videoBase64 = await fileToBase64(publishVideo); const uploadedVideo = await mediaUploadMutation.mutateAsync({ kind: "video", mimeType: publishVideo.type, base64: videoBase64 }); let uploadedThumbnail: { url: string; key: string } | undefined; if (publishThumbnail) { const thumbnailBase64 = await fileToBase64(publishThumbnail); const storedThumbnail = await mediaUploadMutation.mutateAsync({ kind: "thumbnail", mimeType: publishThumbnail.type, base64: thumbnailBase64 }); uploadedThumbnail = { url: storedThumbnail.url, key: storedThumbnail.key }; } await publishMutation.mutateAsync({ title: publishTitle.trim(), description: publishDescription.trim(), videoUrl: uploadedVideo.url, videoStorageKey: uploadedVideo.key, thumbnailUrl: uploadedThumbnail?.url, thumbnailStorageKey: uploadedThumbnail?.key, durationMs: 30_000, accessType: publishAccess, priceCents: publishAccess === "paid" ? publishPrice : 0 }); toast.success("Conteúdo enviado para publicação", { description: "Seu vídeo foi armazenado com segurança e já aparece na biblioteca." }); setPublishOpen(false); setPublishTitle(""); setPublishDescription(""); setPublishVideo(null); setPublishThumbnail(null); } catch (error) { toast.error(error instanceof Error ? error.message : "Não foi possível publicar agora."); } };

  return <main className="kas-app"><div className="kas-noise" /><aside className="sidebar"><div className="brand-lockup"><BrandMark /><div><strong>kas</strong><span>creator network</span></div></div><div className="sidebar-section"><span className="sidebar-label">espaço</span><nav>{NAV_ITEMS.map(item => { const Icon = item.icon; return <button key={item.id} onClick={() => setTab(item.id)} className={tab === item.id ? "nav-item active" : "nav-item"}><Icon size={18} /><span>{item.label}</span>{item.badge && <em>{item.badge}</em>}</button>; })}</nav></div><div className="sidebar-section sidebar-lower"><span className="sidebar-label">seu ritmo</span><button className="nav-item" onClick={() => toast("Agenda em breve", { description: "Você poderá organizar suas próximas lives e publicações." })}><CalendarDays size={18} /><span>Agenda</span></button><button className="nav-item" onClick={() => toast("Configurações em breve")}><Settings2 size={18} /><span>Configurações</span></button></div><div className="sidebar-promo"><div className="promo-orbit"><Sparkles size={17} /></div><strong>Seu tempo<br />tem valor.</strong><p>Reconheça quem cria algo que fica.</p><button onClick={() => setSupportOpen(true)}>explorar Kash <ArrowUpRight size={13} /></button></div><div className="sidebar-footer"><span>kas v0.9 · feito para criar</span><span className="footer-status"><span /> seguro</span></div></aside><section className="workspace"><header className="topbar"><div className="mobile-brand"><BrandMark /><strong>kas</strong></div><div className="breadcrumbs"><span>kas</span><ChevronRight size={13} /><strong>{NAV_ITEMS.find(item => item.id === tab)?.label}</strong></div><div className="topbar-actions"><label className="search-field"><Search size={16} /><input value={searchTerm} onChange={event => setSearchTerm(event.target.value)} placeholder="Buscar criadores, temas..." aria-label="Buscar criadores ou temas" onKeyDown={event => { if (event.key === "Enter") toast(feed.length ? "Busca pronta para explorar" : "Nenhum sinal encontrado", { description: feed.length ? `${feed.length} resultado(s) na sua órbita.` : "Tente o nome de um criador, tema ou hashtag." }); }} /></label><div className="notification-wrap"><IconButton label="Notificações" onClick={() => setNotificationsOpen(value => !value)} active={notificationsOpen}><Bell size={18} /></IconButton>{notificationsOpen && <div className="notification-popover"><div className="popover-heading"><strong>Notificações</strong><span>3 novas</span></div>{["Maya Sol iniciou uma live", "Sua meta semanal está em 86%", "Clube da Lua publicou um exclusivo"].map(item => <button key={item} onClick={() => setNotificationsOpen(false)}><span className="notification-dot" /><span>{item}<small>agora</small></span></button>)}<button className="popover-link">ver todas <ArrowUpRight size={13} /></button></div>}</div>{isAuthenticated ? <button className="profile-pill" onClick={() => toast(`Olá, ${user?.name ?? "criador"}`, { description: "Seu perfil público está em construção." })}><Avatar src={POSTER_URL} /><span>{displayName}</span><ChevronRight size={14} /></button> : <button className="login-button" onClick={() => startLogin()}>Entrar <ArrowUpRight size={14} /></button>}</div></header><div className="workspace-scroll">{tab === "feed" && searchTerm.trim() && feed.length === 0 ? <div className="empty-state"><div className="empty-signal"><Search size={20} /></div><span className="eyebrow">sinal não encontrado</span><h2>Nada saiu desta busca ainda.</h2><p>Tente outro criador, uma categoria ou uma hashtag como <strong>#visual</strong>.</p><button className="solid-button" onClick={() => setSearchTerm("")}>Limpar busca <X size={15} /></button></div> : tab === "feed" && <FeedView feed={feed} currentIndex={currentIndex} setCurrentIndex={setCurrentIndex} currentVideo={currentVideo} isPlaying={isPlaying} setIsPlaying={setIsPlaying} isMuted={isMuted} setIsMuted={setIsMuted} liked={likedVideoIds} onLike={toggleLike} onViewProfile={openProfile} onHashtagSelect={selectHashtag} onLoadMore={loadMoreFeed} onComment={() => setCommentOpen(true)} onSupport={() => setSupportOpen(true)} onShare={shareVideo} onFollow={followCreator} shared={shared} likePulse={likePulse} supportPulse={supportPulse} categories={categories} setCategories={setCategories} />}{tab === "live" && <LiveView onSupport={() => setSupportOpen(true)} />}{tab === "communities" && <CommunitiesView onSubscribe={openSubscribe} onUnlockExclusive={openExclusive} />}{tab === "studio" && <StudioView onPublish={publish} summary={studioQuery.data} />}{tab === "wallet" && <WalletView walletKash={visibleKashMilli} onBuy={buyKash} onPayout={openPayout} />}</div><nav className="mobile-nav">{NAV_ITEMS.map(item => { const Icon = item.icon; return <button key={item.id} onClick={() => setTab(item.id)} className={tab === item.id ? "active" : ""}><Icon size={18} /><span>{item.label.split(" ")[0]}</span></button>; })}</nav></section>{commentOpen && <div className="modal-backdrop" onMouseDown={() => setCommentOpen(false)}><div className="sheet-modal comments-modal" onMouseDown={event => event.stopPropagation()}><button className="modal-close" onClick={() => setCommentOpen(false)}><X size={17} /></button><div className="modal-heading"><span className="eyebrow">conversa</span><h2>Comentários</h2><p>O que a comunidade está sentindo neste vídeo.</p></div><div className="comment-list">{(commentsQuery.data?.map(item => item.comment.content) ?? localComments).map((comment, index) => <div className="comment-row" key={`${comment}-${index}`}><Avatar src={POSTER_URL} /><div><strong>{["bia.frames", "andre.wav", "cami_azul"][index % 3]}</strong><p>{comment}</p><span>agora</span></div></div>)}</div><div className="comment-composer"><input value={draftComment} onChange={event => setDraftComment(event.target.value)} onKeyDown={event => { if (event.key === "Enter") submitComment(); }} placeholder="Deixe uma palavra que fica..." autoFocus /><button onClick={submitComment}><Send size={17} /></button></div></div></div>}{supportOpen && <div className="modal-backdrop" onMouseDown={() => setSupportOpen(false)}><div className="sheet-modal support-modal" onMouseDown={event => event.stopPropagation()}><button className="modal-close" onClick={() => setSupportOpen(false)}><X size={17} /></button><div className="support-hero"><div className="gift-orbit"><Gift size={23} /></div><div><span className="eyebrow">apoio direto</span><h2>Reconheça este momento</h2><p>Seu Kash vira presença para {currentVideo.creator.name} continuar criando.</p></div></div><div className="support-amounts gift-grid">{KAS_GIFTS.map(gift => <button key={gift.slug} onClick={() => { setSelectedGift(gift.slug); setSelectedKash(gift.costKash); }} className={selectedGift === gift.slug ? "selected gift-card" : "gift-card"}><Gift size={16} /><span><strong>{gift.label}</strong><small>{gift.description}</small></span><b>{gift.costKash} Kash</b></button>)}</div><div className="support-split"><span>vai para o criador <strong>{(selectedKash * .85).toFixed(0)} Kash</strong></span><span>efeito selecionado <strong>{KAS_GIFTS.find(item => item.slug === selectedGift)?.effectKey}</strong></span></div><button className="solid-button full-width" onClick={sendSupport}>Enviar {KAS_GIFTS.find(item => item.slug === selectedGift)?.label ?? "presente"} <ArrowUpRight size={15} /></button><button className="text-button full-width center" onClick={buyKash}><WalletCards size={14} /> recarregar minha carteira</button></div></div>}{publishOpen && <div className="modal-backdrop" onMouseDown={() => setPublishOpen(false)}><div className="sheet-modal publish-modal" onMouseDown={event => event.stopPropagation()}><button className="modal-close" onClick={() => setPublishOpen(false)}><X size={17} /></button><div className="modal-heading"><span className="eyebrow">creator studio</span><h2>Publicar algo que fica</h2><p>Vídeos e capas ficam protegidos no storage do KAS e vinculados ao seu perfil.</p></div><div className="publish-form"><label><span>Título do conteúdo</span><input value={publishTitle} onChange={event => setPublishTitle(event.target.value)} placeholder="Ex.: O som antes da imagem" maxLength={140} /></label><label><span>Legenda</span><textarea value={publishDescription} onChange={event => setPublishDescription(event.target.value)} placeholder="Conte o contexto em poucas palavras..." maxLength={500} /></label><div className="publish-file-grid"><label className="file-drop"><Video size={17} /><span>{publishVideo ? publishVideo.name : "Escolher vídeo"}</span><small>MP4 ou WebM · até 5 MB</small><input type="file" accept="video/mp4,video/webm" onChange={event => setPublishVideo(event.target.files?.[0] ?? null)} /></label><label className="file-drop"><Clapperboard size={17} /><span>{publishThumbnail ? publishThumbnail.name : "Adicionar capa"}</span><small>JPG, PNG ou WebP · até 3 MB</small><input type="file" accept="image/jpeg,image/png,image/webp" onChange={event => setPublishThumbnail(event.target.files?.[0] ?? null)} /></label></div><div className="publish-access-row"><label><span>Quem pode acessar?</span><select value={publishAccess} onChange={event => setPublishAccess(event.target.value as "public" | "community" | "paid")}><option value="public">Público</option><option value="community">Minha comunidade</option><option value="paid">Pago / exclusivo</option></select></label>{publishAccess === "paid" && <label><span>Preço em centavos</span><input type="number" min={100} step={100} value={publishPrice} onChange={event => setPublishPrice(Number(event.target.value))} /></label>}</div><div className="publish-safe-note"><ShieldCheck size={15} /><span>Sem cartão armazenado no KAS. A compra e o desbloqueio são processados com checkout seguro.</span></div><button className="solid-button full-width" disabled={publishMutation.isPending || mediaUploadMutation.isPending} onClick={submitPublish}>{publishMutation.isPending || mediaUploadMutation.isPending ? "Enviando..." : "Publicar conteúdo"} <ArrowUpRight size={15} /></button></div></div></div>}{profileOpen && <div className="modal-backdrop" onMouseDown={() => setProfileOpen(false)}><div className="sheet-modal creator-profile-modal" onMouseDown={event => event.stopPropagation()}><button className="modal-close" onClick={() => setProfileOpen(false)}><X size={17} /></button><div className="profile-modal-cover"><div className="profile-modal-avatar"><Avatar src={currentVideo.creator.avatarUrl} /></div><span className="profile-level"><Crown size={12} /> círculo · 3 anos criando</span></div><div className="profile-modal-body"><div className="profile-modal-heading"><div><h2>{currentVideo.creator.name}</h2><span>{currentVideo.creator.handle} · {currentVideo.creator.followers} seguidores</span></div><button className="solid-button" onClick={followCreator}>{followedCreatorIds.includes(currentVideo.creator.id) ? "Seguindo" : "Seguir"}</button></div><p className="profile-bio">{currentVideo.creator.bio} Construindo imagens e encontros que continuam depois do play.</p><div className="profile-stat-grid"><div><strong>42</strong><span>publicações</span></div><div><strong>18</strong><span>drops exclusivos</span></div><div><strong>4,8%</strong><span>engajamento</span></div></div><div className="profile-content-preview"><div className="panel-heading"><div><span className="eyebrow">conteúdo publicado</span><h3>Uma seleção recente</h3></div><ArrowUpRight size={15} /></div><div className="profile-content-row"><div className="content-thumb thumb-0"><Video size={16} /></div><div><strong>{currentVideo.title}</strong><span>vídeo curto · 128 mil views</span></div><Check size={15} /></div><div className="profile-content-row"><div className="content-thumb thumb-1"><LockKeyhole size={16} /></div><div><strong>Notas de processo</strong><span>exclusivo para o Círculo</span></div><span className="profile-price">R$ 7,90</span></div></div><div className="profile-schedule"><CalendarDays size={16} /><div><span className="eyebrow">próxima agenda</span><strong>Feedback sem filtro · quarta, 20:30</strong></div><ChevronRight size={15} /></div><button className="solid-button full-width" onClick={() => setSupportOpen(true)}><Gift size={15} /> Apoiar {currentVideo.creator.name}</button></div></div></div>}{publishOpen && <div className="modal-backdrop" onMouseDown={() => setPublishOpen(false)}><div className="sheet-modal publish-modal" onMouseDown={event => event.stopPropagation()}><button className="modal-close" onClick={() => setPublishOpen(false)}><X size={17} /></button><div className="modal-heading"><span className="eyebrow">creator studio</span><h2>Publicar algo que fica</h2><p>Vídeos e capas ficam protegidos no storage do KAS e vinculados ao seu perfil.</p></div><div className="publish-form"><label><span>Título do conteúdo</span><input value={publishTitle} onChange={event => setPublishTitle(event.target.value)} placeholder="Ex.: O som antes da imagem" maxLength={140} /></label><label><span>Legenda</span><textarea value={publishDescription} onChange={event => setPublishDescription(event.target.value)} placeholder="Conte o contexto em poucas palavras..." maxLength={500} /></label><div className="publish-file-grid"><label className="file-drop"><Video size={17} /><span>{publishVideo ? publishVideo.name : "Escolher vídeo"}</span><small>MP4 ou WebM · até 5 MB</small><input type="file" accept="video/mp4,video/webm" onChange={event => setPublishVideo(event.target.files?.[0] ?? null)} /></label><label className="file-drop"><Clapperboard size={17} /><span>{publishThumbnail ? publishThumbnail.name : "Adicionar capa"}</span><small>JPG, PNG ou WebP · até 3 MB</small><input type="file" accept="image/jpeg,image/png,image/webp" onChange={event => setPublishThumbnail(event.target.files?.[0] ?? null)} /></label></div><div className="publish-access-row"><label><span>Quem pode acessar?</span><select value={publishAccess} onChange={event => setPublishAccess(event.target.value as "public" | "community" | "paid")}><option value="public">Público</option><option value="community">Minha comunidade</option><option value="paid">Pago / exclusivo</option></select></label>{publishAccess === "paid" && <label><span>Preço em centavos</span><input type="number" min={100} step={100} value={publishPrice} onChange={event => setPublishPrice(Number(event.target.value))} /></label>}</div><div className="publish-safe-note"><ShieldCheck size={15} /><span>Sem cartão armazenado no KAS. A compra e o desbloqueio são processados com checkout seguro.</span></div><button className="solid-button full-width" disabled={publishMutation.isPending || mediaUploadMutation.isPending} onClick={submitPublish}>{publishMutation.isPending || mediaUploadMutation.isPending ? "Enviando..." : "Publicar conteúdo"} <ArrowUpRight size={15} /></button></div></div></div>}</main>;
}
