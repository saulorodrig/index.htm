export type KasGift = {
  slug: string;
  label: string;
  description: string;
  costKash: number;
  effectKey: string;
  tone: "lime" | "violet" | "gold" | "pink";
};

export const KAS_GIFTS: KasGift[] = [
  { slug: "orbit-glow", label: "Brilho de Órbita", description: "um pulso que acende a sala", costKash: 20, effectKey: "orbit-glow", tone: "lime" },
  { slug: "pulse-heart", label: "Coração Pulse", description: "presença em movimento", costKash: 50, effectKey: "pulse-heart", tone: "pink" },
  { slug: "lion-signal", label: "Leão Solar", description: "força, proteção e palco", costKash: 500, effectKey: "lion-signal", tone: "gold" },
  { slug: "constellation-crown", label: "Coroa Constelação", description: "um marco para a comunidade", costKash: 1_200, effectKey: "constellation-crown", tone: "violet" },
];

export function getGiftBySlug(slug: string) {
  return KAS_GIFTS.find(gift => gift.slug === slug);
}
