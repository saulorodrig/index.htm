CREATE TABLE `transactions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`transactionType` enum('kash_purchase','creator_support','creator_earning','payout_request','payout_completed','refund') NOT NULL,
	`transactionStatus` enum('pending','completed','failed','cancelled') NOT NULL DEFAULT 'pending',
	`senderWalletId` int,
	`receiverWalletId` int,
	`videoId` int,
	`kashMilliAmount` int NOT NULL DEFAULT 0,
	`creatorKashMilli` int NOT NULL DEFAULT 0,
	`platformKashMilli` int NOT NULL DEFAULT 0,
	`brlCentsAmount` int NOT NULL DEFAULT 0,
	`stripePaymentIntentId` varchar(255),
	`stripePayoutId` varchar(255),
	`metadata` json,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `transactions_id` PRIMARY KEY(`id`),
	CONSTRAINT `transactions_payment_intent_unique` UNIQUE(`stripePaymentIntentId`)
);
--> statement-breakpoint
CREATE TABLE `videoComments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`videoId` int NOT NULL,
	`userId` int NOT NULL,
	`content` varchar(500) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `videoComments_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `videoLikes` (
	`id` int AUTO_INCREMENT NOT NULL,
	`videoId` int NOT NULL,
	`userId` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `videoLikes_id` PRIMARY KEY(`id`),
	CONSTRAINT `video_likes_video_user_unique` UNIQUE(`videoId`,`userId`)
);
--> statement-breakpoint
CREATE TABLE `videoViewEvents` (
	`id` int AUTO_INCREMENT NOT NULL,
	`videoId` int NOT NULL,
	`viewerUserId` int,
	`retentionMs` int NOT NULL,
	`isValid` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `videoViewEvents_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `videos` (
	`id` int AUTO_INCREMENT NOT NULL,
	`creatorId` int NOT NULL,
	`title` varchar(140) NOT NULL,
	`description` text,
	`videoUrl` text NOT NULL,
	`videoStorageKey` varchar(512),
	`thumbnailUrl` text,
	`thumbnailStorageKey` varchar(512),
	`durationMs` int NOT NULL,
	`videoVisibility` enum('public','unlisted','private') NOT NULL DEFAULT 'public',
	`videoStatus` enum('draft','processing','published','rejected') NOT NULL DEFAULT 'draft',
	`totalViews` int NOT NULL DEFAULT 0,
	`totalLikes` int NOT NULL DEFAULT 0,
	`averageRetentionMs` int NOT NULL DEFAULT 0,
	`publishedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `videos_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `wallets` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`brlBalanceCents` int NOT NULL DEFAULT 0,
	`kashMilliBalance` int NOT NULL DEFAULT 0,
	`pendingPayoutCents` int NOT NULL DEFAULT 0,
	`kycStatus` enum('not_started','pending','verified','rejected') NOT NULL DEFAULT 'not_started',
	`stripeCustomerId` varchar(255),
	`stripeAccountId` varchar(255),
	`payoutsEnabled` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `wallets_id` PRIMARY KEY(`id`),
	CONSTRAINT `wallets_user_id_unique` UNIQUE(`userId`)
);
--> statement-breakpoint
ALTER TABLE `users` MODIFY COLUMN `role` enum('user','admin','creator') NOT NULL DEFAULT 'user';--> statement-breakpoint
ALTER TABLE `users` ADD `handle` varchar(40);--> statement-breakpoint
ALTER TABLE `users` ADD `avatarUrl` text;--> statement-breakpoint
ALTER TABLE `users` ADD `avatarStorageKey` varchar(512);--> statement-breakpoint
ALTER TABLE `users` ADD `bio` varchar(280);--> statement-breakpoint
ALTER TABLE `users` ADD `followerCount` int DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `users` ADD `followingCount` int DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `users` ADD CONSTRAINT `users_handle_unique` UNIQUE(`handle`);--> statement-breakpoint
ALTER TABLE `transactions` ADD CONSTRAINT `transactions_senderWalletId_wallets_id_fk` FOREIGN KEY (`senderWalletId`) REFERENCES `wallets`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `transactions` ADD CONSTRAINT `transactions_receiverWalletId_wallets_id_fk` FOREIGN KEY (`receiverWalletId`) REFERENCES `wallets`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `transactions` ADD CONSTRAINT `transactions_videoId_videos_id_fk` FOREIGN KEY (`videoId`) REFERENCES `videos`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `videoComments` ADD CONSTRAINT `videoComments_videoId_videos_id_fk` FOREIGN KEY (`videoId`) REFERENCES `videos`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `videoComments` ADD CONSTRAINT `videoComments_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `videoLikes` ADD CONSTRAINT `videoLikes_videoId_videos_id_fk` FOREIGN KEY (`videoId`) REFERENCES `videos`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `videoLikes` ADD CONSTRAINT `videoLikes_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `videoViewEvents` ADD CONSTRAINT `videoViewEvents_videoId_videos_id_fk` FOREIGN KEY (`videoId`) REFERENCES `videos`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `videoViewEvents` ADD CONSTRAINT `videoViewEvents_viewerUserId_users_id_fk` FOREIGN KEY (`viewerUserId`) REFERENCES `users`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `videos` ADD CONSTRAINT `videos_creatorId_users_id_fk` FOREIGN KEY (`creatorId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `wallets` ADD CONSTRAINT `wallets_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `transactions_sender_created_idx` ON `transactions` (`senderWalletId`,`createdAt`);--> statement-breakpoint
CREATE INDEX `transactions_receiver_created_idx` ON `transactions` (`receiverWalletId`,`createdAt`);--> statement-breakpoint
CREATE INDEX `transactions_type_status_idx` ON `transactions` (`transactionType`,`transactionStatus`);--> statement-breakpoint
CREATE INDEX `video_comments_video_created_idx` ON `videoComments` (`videoId`,`createdAt`);--> statement-breakpoint
CREATE INDEX `video_likes_user_idx` ON `videoLikes` (`userId`);--> statement-breakpoint
CREATE INDEX `video_view_events_video_created_idx` ON `videoViewEvents` (`videoId`,`createdAt`);--> statement-breakpoint
CREATE INDEX `video_view_events_viewer_idx` ON `videoViewEvents` (`viewerUserId`);--> statement-breakpoint
CREATE INDEX `videos_creator_published_idx` ON `videos` (`creatorId`,`publishedAt`);--> statement-breakpoint
CREATE INDEX `videos_feed_idx` ON `videos` (`videoStatus`,`videoVisibility`,`publishedAt`);