import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import { executeFeedShortcut } from "@/lib/feedShortcuts";
import {
  Bell,
  ChevronDown,
  ChevronUp,
  Clapperboard,
  Compass,
  Eye,
  Gift,
  Heart,
  House,
  MessageCircle,
  MoreHorizontal,
  Pause,
  Play,
  Search,
  Send,
  Settings,
  Share2,
  Sparkles,
  UsersRound,
  Volume2,
  VolumeX,
  WalletCards,
  X,
} from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { toast } from "sonner";

const POSTER_URL = "/manus-storage/kas-neon-creator_d60cf531.jpg";
const SAMPLE_VIDEO_URL = "https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4";

type ViewVideo = {
  id: number;
  title: string;
  caption: string;
  url: string;
  poster: string;
  views: number;
  likes: number;
  creator: { id: number; name: string; handle: string; bio: string; followers: string; avatar: string };
};

const FALLBACK_FEED: ViewVideo[] = [
  {
    id: 1, title: "Midnight bloom", caption: "Um minuto para desacelerar e deixar a noite falar. #visual #mood", url: SAMPLE_VIDEO_URL, poster: POSTER_URL, views: 128400, likes: 18400,
    creator: { id: 101, name: "Luna Kyo", handle: "@lunakyo", bio: "Direção criativa, luz e movimento.", followers: "248 mil", avatar: POSTER_URL },
  },
  {
    id: 2, title: "Purple frequency", caption: "Quando a cidade vira textura e cada luz encontra um ritmo. #nightshift", url: SAMPLE_VIDEO_URL, poster: POSTER_URL, views: 89300, likes: 9600,
    creator: { id: 102, name: "Kai Avenue", handle: "@kaiavenue", bio: "Filmes breves para horas longas.", followers: "96,4 mil", avatar: POSTER_URL },
  },
  {
    id: 3, title: "Signal 03", caption: "Estudo de cor, ruído e presença. Salve para ver de novo depois.", url: SAMPLE_VIDEO_URL, poster: POSTER_URL, views: 54700, likes: 7200,
    creator: { id: 103, name: "Noah Rami", handle: "@noahrami", bio: "Cenas digitais e objetos imaginários.", followers: "71,8 mil", avatar: POSTER_URL },
  },
];

const NAV_ITEMS = [
  ["Para você", House], ["Descobrir", Compass], ["Criadores", UsersRound], ["Kash", WalletCards], ["Configurações", Settings],
] as const;

const compact = (value: number) => new Intl.NumberFormat("pt-BR", { notation: "compact", maximumFractionDigits: 1 }).format(value);
const formatKash = (milli: number) => new Intl.NumberFormat("pt-BR", { maximumFractionDigits: 0 }).format(milli / 1000);

function ComingSoon({ label }: { label: string }) {
  toast("Módulo previsto para a próxima etapa", { description: `${label} ainda não está disponível nesta prévia do MVP.` });
}

export default function KasFeedView() {
  const { isAuthenticated } = useAuth();
  const utils = trpc.useUtils();
  const videoRef = useRef<HTMLVideoElement>(null);
  const [index, setIndex] = useState(0);
  const [playing, setPlaying] = useState(true);
  const [muted, setMuted] = useState(true);
  const [liked, setLiked] = useState<number[]>([]);
  const [commentOpen, setCommentOpen] = useState(false);
  const [supportOpen, setSupportOpen] = useState(false);
  const [comment, setComment] = useState("");
  const [comments, setComments] = useState(["A textura está incrível.", "Essa paleta ficou memorável."]);
  const [amount, setAmount] = useState(40);
  const [demoKash, setDemoKash] = useState(1_280_000);
  const [shared, setShared] = useState(false);

  const feedInput = useMemo(() => ({ limit: 10 }), []);
  const feedQuery = trpc.kas.feed.list.useQuery(feedInput);
  const walletQuery = trpc.kas.wallet.me.useQuery(undefined, { enabled: isAuthenticated });
  const likeMutation = trpc.kas.feed.toggleLike.useMutation();
  const supportMutation = trpc.kas.wallet.supportCreator.useMutation();
  const recordViewMutation = trpc.kas.feed.recordView.useMutation();
  const createCommentMutation = trpc.kas.feed.createComment.useMutation();
  const checkoutMutation = trpc.kas.wallet.createCheckout.useMutation();

  const apiFeed = useMemo<ViewVideo[]>(() => (feedQuery.data ?? []).map(({ video, creator }) => ({
    id: video.id,
    title: video.title,
    caption: video.description ?? "",
    url: video.videoUrl,
    poster: video.thumbnailUrl ?? POSTER_URL,
    views: video.totalViews,
    likes: video.totalLikes,
    creator: {
      id: creator.id,
      name: creator.name ?? "Criador kas",
      handle: creator.handle ? `@${creator.handle.replace(/^@/, "")}` : "@criador",
      bio: creator.bio ?? "Criador em destaque no kas.",
      followers: compact(creator.followerCount),
      avatar: creator.avatarUrl ?? POSTER_URL,
    },
  })), [feedQuery.data]);
  const feed = apiFeed.length ? apiFeed : FALLBACK_FEED;
  const current = feed[index % feed.length] ?? FALLBACK_FEED[0];
  const databaseVideo = apiFeed.length > 0;
  const walletMilli = walletQuery.data?.kashMilliBalance || demoKash;
  const commentsInput = useMemo(() => ({ videoId: current.id }), [current.id]);
  const commentsQuery = trpc.kas.feed.comments.useQuery(commentsInput, { enabled: databaseVideo && commentOpen });

  const changeVideo = (direction: 1 | -1) => {
    setIndex(value => (value + direction + feed.length) % feed.length);
    setPlaying(true);
  };

  useEffect(() => {
    const player = videoRef.current;
    if (!player) return;
    player.muted = muted;
    if (playing) player.play().catch(() => setPlaying(false));
    else player.pause();
  }, [index, muted, playing]);

  useEffect(() => {
    if (!databaseVideo) return;
    const timer = window.setTimeout(() => recordViewMutation.mutate({ videoId: current.id, retainedMs: 3000 }), 3000);
    return () => window.clearTimeout(timer);
  }, [current.id, databaseVideo, recordViewMutation]);

  useEffect(() => {
    const shortcut = (event: KeyboardEvent) => {
      const tag = (event.target as HTMLElement | null)?.tagName;
      executeFeedShortcut({
        key: event.key,
        isEditing: tag === "INPUT" || tag === "TEXTAREA" || commentOpen || supportOpen,
        preventDefault: () => event.preventDefault(),
        onPrevious: () => changeVideo(-1),
        onNext: () => changeVideo(1),
        onTogglePlay: () => setPlaying(value => !value),
        onToggleMute: () => setMuted(value => !value),
      });
    };
    window.addEventListener("keydown", shortcut);
    return () => window.removeEventListener("keydown", shortcut);
  }, [commentOpen, feed.length, supportOpen]);

  const toggleLike = () => {
    const isLiked = liked.includes(current.id);
    setLiked(values => isLiked ? values.filter(id => id !== current.id) : [...values, current.id]);
    if (isAuthenticated && databaseVideo) {
      likeMutation.mutate({ videoId: current.id }, { onSuccess: () => utils.kas.feed.list.invalidate() });
    } else if (!isAuthenticated) {
      toast("Curtida salva nesta prévia", { description: "Entre para sincronizar suas interações." });
    }
  };

  const share = async () => {
    try {
      if (navigator.share) await navigator.share({ title: current.title, text: current.caption, url: window.location.href });
      else { await navigator.clipboard.writeText(window.location.href); toast.success("Link copiado para a área de transferência."); }
      setShared(true);
    } catch { /* cancelamento não exige mensagem */ }
  };

  const submitComment = () => {
    const normalized = comment.trim();
    if (!normalized) return;
    setComments(values => [normalized, ...values]);
    setComment("");
    toast.success("Comentário adicionado à prévia.");
    if (isAuthenticated && databaseVideo) {
      createCommentMutation.mutate({ videoId: current.id, content: normalized }, { onSuccess: () => commentsQuery.refetch() });
    }
  };

  const sendSupport = () => {
    const milli = amount * 1000;
    if (walletMilli < milli) { toast.error("Saldo Kash insuficiente."); return; }
    setDemoKash(value => value - milli);
    setSupportOpen(false);
    toast.success(`${amount} Kash enviados para ${current.creator.name}`, { description: `${amount * 0.85} Kash seguem para o criador; a taxa do kas é de 15%.` });
    if (isAuthenticated && databaseVideo) {
      supportMutation.mutate(
        { creatorUserId: current.creator.id, videoId: current.id, kashMilli: milli },
        { onSuccess: () => utils.kas.wallet.me.invalidate(), onError: error => { setDemoKash(value => value + milli); toast.error(error.message); } },
      );
    }
  };

  const buyKash = () => {
    if (!isAuthenticated) {
      toast("Entre para recarregar Kash", { description: "A compra é vinculada à carteira da sua conta." });
      return;
    }
    checkoutMutation.mutate({ packageId: "starter" }, {
      onSuccess: ({ checkoutUrl }) => {
        if (checkoutUrl) window.open(checkoutUrl, "_blank", "noopener,noreferrer");
      },
      onError: error => toast.error(error.message),
    });
  };

  return (
    <main className="min-h-screen overflow-hidden bg-[#09090d] text-[#f5f2ff]">
      <div className="kas-ambient kas-ambient-one" />
      <div className="kas-ambient kas-ambient-two" />
      <div className="relative mx-auto grid min-h-screen max-w-[1680px] grid-cols-1 lg:grid-cols-[250px_minmax(440px,1fr)_330px] xl:grid-cols-[280px_minmax(520px,1fr)_360px]">
        <aside className="hidden border-r border-white/[.07] bg-[#0e0e14]/75 px-5 py-7 backdrop-blur-xl lg:flex lg:flex-col">
          <div className="mb-12 flex items-center gap-3 px-2">
            <div className="grid size-10 place-items-center rounded-2xl bg-gradient-to-br from-violet-400 to-fuchsia-600 shadow-[0_0_28px_rgba(143,91,255,.42)]"><Clapperboard className="size-5" /></div>
            <span className="font-display text-2xl font-bold tracking-[-.08em]">kas</span>
          </div>
          <nav className="space-y-1.5">
            {NAV_ITEMS.map(([label, Icon], itemIndex) => (
              <button key={label} onClick={() => itemIndex ? ComingSoon({ label }) : undefined} className={`flex w-full items-center gap-3 rounded-xl px-3 py-3 text-left text-sm font-medium transition ${itemIndex === 0 ? "bg-violet-500/15 text-white" : "text-[#a5a1b5] hover:bg-white/[.055] hover:text-white"}`}>
                <Icon className={`size-[18px] ${itemIndex === 0 ? "text-violet-300" : "text-[#7d788f]"}`} />
                {label}
                {label === "Kash" && <span className="ml-auto rounded-md bg-violet-400/15 px-1.5 py-0.5 text-[10px] font-semibold text-violet-200">novo</span>}
              </button>
            ))}
          </nav>
          <div className="mt-auto rounded-2xl border border-violet-400/15 bg-gradient-to-br from-violet-500/15 to-fuchsia-500/[.06] p-4">
            <Sparkles className="mb-3 size-5 text-violet-300" />
            <p className="text-sm font-semibold">Seu tempo tem valor.</p>
            <p className="mt-1 text-xs leading-5 text-[#aaa5ba]">Apoie quem transforma seu feed em algo memorável.</p>
            <button onClick={() => setSupportOpen(true)} className="mt-4 text-xs font-bold text-violet-200 hover:text-white">Explorar Kash →</button>
          </div>
        </aside>

        <section className="relative flex min-h-screen flex-col border-white/[.07] lg:border-r">
          <header className="flex h-20 shrink-0 items-center justify-between border-b border-white/[.07] px-5 sm:px-8">
            <div className="flex items-center gap-2 lg:hidden"><Clapperboard className="size-6 text-violet-300" /><span className="font-display text-xl font-bold tracking-[-.08em]">kas</span></div>
            <div className="hidden items-center gap-1 rounded-xl bg-white/[.04] p-1 sm:flex"><button className="rounded-lg bg-white/[.1] px-4 py-2 text-sm font-semibold">Para você</button><button onClick={() => ComingSoon({ label: "Seguindo" })} className="rounded-lg px-4 py-2 text-sm font-medium text-[#a5a1b5] hover:text-white">Seguindo</button></div>
            <div className="flex items-center gap-2"><button aria-label="Buscar" onClick={() => ComingSoon({ label: "Busca" })} className="grid size-9 place-items-center rounded-xl text-[#b8b3c9] hover:bg-white/[.06] hover:text-white"><Search className="size-[18px]" /></button><button aria-label="Notificações" onClick={() => toast("Sem novas notificações")} className="grid size-9 place-items-center rounded-xl text-[#b8b3c9] hover:bg-white/[.06] hover:text-white"><Bell className="size-[18px]" /></button><img src={POSTER_URL} alt="Seu perfil" className="ml-1 size-8 rounded-full border border-violet-300/30 object-cover" /></div>
          </header>
          <div className="relative flex min-h-0 flex-1 items-center justify-center px-4 py-5 sm:px-8 sm:py-6">
            <div className="relative h-[calc(100vh-9.5rem)] min-h-[560px] max-h-[780px] w-full max-w-[438px] overflow-hidden rounded-[28px] border border-white/10 bg-[#12111a] shadow-[0_26px_80px_rgba(0,0,0,.55)]">
              <video ref={videoRef} className="size-full object-cover" src={current.url} poster={current.poster} muted={muted} loop playsInline autoPlay onClick={() => setPlaying(value => !value)} />
              <div className="absolute inset-0 bg-[linear-gradient(180deg,rgba(0,0,0,.45)_0%,transparent_32%,transparent_54%,rgba(7,6,13,.91)_100%)]" />
              <div className="absolute left-4 top-4 flex items-center gap-2 rounded-full border border-white/10 bg-black/20 px-3 py-1.5 text-[11px] font-medium text-white/85 backdrop-blur-md"><span className="size-1.5 animate-pulse rounded-full bg-fuchsia-400" /> Para você</div>
              <button aria-label={playing ? "Pausar vídeo" : "Reproduzir vídeo"} onClick={() => setPlaying(value => !value)} className={`absolute left-1/2 top-1/2 grid size-14 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full bg-white/20 text-white backdrop-blur transition ${playing ? "opacity-0 hover:opacity-100" : "opacity-100"}`}>{playing ? <Pause className="size-5 fill-white" /> : <Play className="ml-0.5 size-5 fill-white" />}</button>
              <div className="absolute bottom-0 left-0 right-0 p-5 pt-16">
                <div className="mb-3 flex items-center gap-2"><img src={current.creator.avatar} alt="" className="size-8 rounded-full border border-white/30 object-cover" /><span className="text-sm font-bold">{current.creator.handle}</span><button onClick={() => toast("Perfil seguido")} className="rounded-lg bg-white px-2.5 py-1 text-[10px] font-bold text-black hover:bg-violet-100">Seguir</button></div>
                <h1 className="font-display text-xl font-semibold tracking-[-.03em]">{current.title}</h1><p className="mt-1.5 max-w-[310px] text-sm leading-5 text-white/75">{current.caption}</p><div className="mt-4 flex items-center gap-2 text-xs text-white/60"><Eye className="size-3.5" /> {compact(current.views)} visualizações <span className="mx-1 text-white/25">•</span> som original</div>
              </div>
              <div className="absolute bottom-5 right-4 flex flex-col items-center gap-4">
                <button onClick={toggleLike} className="group flex flex-col items-center gap-1.5" aria-label="Curtir vídeo"><span className={`grid size-10 place-items-center rounded-full border border-white/15 bg-black/20 backdrop-blur ${liked.includes(current.id) ? "text-pink-400" : "text-white"}`}><Heart className={`size-5 ${liked.includes(current.id) ? "fill-current" : ""}`} /></span><span className="text-[10px]">{compact(current.likes + (liked.includes(current.id) ? 1 : 0))}</span></button>
                <button onClick={() => setCommentOpen(true)} className="group flex flex-col items-center gap-1.5" aria-label="Abrir comentários"><span className="grid size-10 place-items-center rounded-full border border-white/15 bg-black/20 text-white backdrop-blur"><MessageCircle className="size-5" /></span><span className="text-[10px]">{comments.length}</span></button>
                <button onClick={share} className="group flex flex-col items-center gap-1.5" aria-label="Compartilhar vídeo"><span className={`grid size-10 place-items-center rounded-full border border-white/15 bg-black/20 backdrop-blur ${shared ? "text-violet-200" : "text-white"}`}><Share2 className="size-5" /></span><span className="text-[10px]">{shared ? "Enviado" : "Enviar"}</span></button>
                <button onClick={() => setMuted(value => !value)} className="grid size-10 place-items-center rounded-full border border-white/15 bg-black/20 text-white backdrop-blur" aria-label="Alternar som">{muted ? <VolumeX className="size-4" /> : <Volume2 className="size-4" />}</button>
              </div>
              <div className="absolute bottom-0 left-0 h-0.5 w-full bg-white/20"><div className="h-full w-[46%] bg-violet-300 shadow-[0_0_10px_rgba(196,181,253,.9)]" /></div>
            </div>
            <div className="absolute left-3 top-1/2 hidden -translate-y-1/2 flex-col gap-2 xl:flex"><button onClick={() => changeVideo(-1)} aria-label="Vídeo anterior" className="grid size-10 place-items-center rounded-xl border border-white/[.08] bg-white/[.04] text-[#b5afc7] hover:bg-white/10 hover:text-white"><ChevronUp className="size-5" /></button><button onClick={() => changeVideo(1)} aria-label="Próximo vídeo" className="grid size-10 place-items-center rounded-xl border border-white/[.08] bg-white/[.04] text-[#b5afc7] hover:bg-white/10 hover:text-white"><ChevronDown className="size-5" /></button></div>
          </div>
          <footer className="hidden h-10 items-center justify-center gap-4 border-t border-white/[.06] text-[10px] font-medium text-[#777183] sm:flex"><span>↑ ↓ navegar</span><span>Espaço pausar</span><span>M mutar</span></footer>
        </section>

        <aside className="hidden bg-[#0d0d13]/70 px-6 py-7 backdrop-blur-xl lg:block">
          <div className="mb-8 flex items-center justify-between"><p className="text-xs font-bold uppercase tracking-[.18em] text-[#8b849e]">Agora no seu feed</p><button onClick={() => ComingSoon({ label: "Opções do criador" })} aria-label="Mais opções" className="text-[#8b849e] hover:text-white"><MoreHorizontal className="size-5" /></button></div>
          <section className="rounded-2xl border border-white/[.08] bg-white/[.035] p-4 shadow-xl shadow-black/10"><div className="flex items-start gap-3"><img src={current.creator.avatar} className="size-12 rounded-2xl object-cover" alt={`Avatar de ${current.creator.name}`} /><div className="min-w-0 flex-1"><div className="flex items-center justify-between gap-2"><div><p className="truncate text-sm font-bold">{current.creator.name}</p><p className="mt-0.5 text-xs text-[#9790a8]">{current.creator.handle}</p></div><button onClick={() => toast("Perfil seguido")} className="rounded-lg border border-violet-300/35 px-2.5 py-1.5 text-[10px] font-bold text-violet-200 hover:bg-violet-400/10">Seguir</button></div></div></div><p className="mt-4 text-xs leading-5 text-[#aaa4b8]">{current.creator.bio}</p><div className="mt-4 grid grid-cols-2 border-t border-white/[.08] pt-4"><div><p className="text-sm font-bold">{current.creator.followers}</p><p className="mt-0.5 text-[10px] text-[#817b90]">seguidores</p></div><div className="border-l border-white/[.08] pl-4"><p className="text-sm font-bold">142</p><p className="mt-0.5 text-[10px] text-[#817b90]">vídeos</p></div></div></section>
          <section className="mt-5 overflow-hidden rounded-2xl border border-violet-400/20 bg-[linear-gradient(145deg,rgba(119,76,255,.24),rgba(24,20,39,.8)_60%,rgba(10,10,15,.95))] p-5"><div className="flex items-start justify-between"><div className="grid size-10 place-items-center rounded-xl bg-violet-300/15 text-violet-200"><Gift className="size-5" /></div><span className="rounded-full bg-violet-200/10 px-2 py-1 text-[10px] font-bold text-violet-100">APOIE</span></div><h2 className="mt-5 font-display text-lg font-semibold tracking-[-.03em]">Envie Kash para<br />{current.creator.name.split(" ")[0]}.</h2><p className="mt-2 text-xs leading-5 text-[#c0b9d1]">85% vai direto para o criador. Você decide cada apoio.</p><button onClick={() => setSupportOpen(true)} className="mt-5 flex w-full items-center justify-center gap-2 rounded-xl bg-white py-3 text-xs font-extrabold text-[#17121f] hover:bg-violet-100"><Gift className="size-4" /> Apoiar com Kash</button></section>
          <section className="mt-5 rounded-2xl border border-white/[.07] bg-white/[.025] p-4"><div className="flex items-center justify-between"><div className="flex items-center gap-2"><div className="grid size-8 place-items-center rounded-lg bg-amber-300/10 text-amber-200"><WalletCards className="size-4" /></div><span className="text-xs font-semibold">Sua carteira</span></div><button onClick={buyKash} disabled={checkoutMutation.isPending} className="text-[10px] font-bold text-violet-300 hover:text-violet-100">{checkoutMutation.isPending ? "Abrindo..." : "Recarregar"}</button></div><p className="mt-4 font-display text-2xl font-semibold tracking-[-.05em]">{formatKash(walletMilli)} <span className="text-sm text-[#9f98ad]">Kash</span></p><p className="mt-1 text-[10px] text-[#7f788e]">Saldo disponível nesta prévia</p></section>
        </aside>
      </div>

      {commentOpen && <div className="fixed inset-0 z-30 flex items-end justify-center bg-black/70 p-3 backdrop-blur-sm sm:items-center"><section role="dialog" aria-modal="true" aria-label="Comentários" className="w-full max-w-lg overflow-hidden rounded-3xl border border-white/10 bg-[#16151e] shadow-2xl"><header className="flex items-center justify-between border-b border-white/[.08] px-5 py-4"><div><p className="font-display text-lg font-semibold">Comentários</p><p className="mt-0.5 text-xs text-[#928b9f]">A conversa sobre este momento.</p></div><button onClick={() => setCommentOpen(false)} className="grid size-9 place-items-center rounded-xl text-[#aaa4b8] hover:bg-white/[.06] hover:text-white"><X className="size-5" /></button></header><div className="max-h-[48vh] space-y-5 overflow-y-auto px-5 py-5">{commentsQuery.data?.map(({ comment: persisted, author }) => <div className="flex gap-3" key={persisted.id}><img src={author.avatarUrl ?? POSTER_URL} className="size-9 rounded-full object-cover" alt="" /><div><p className="text-xs font-bold">{author.name ?? "Membro kas"} <span className="ml-1 font-normal text-[#807989]">agora</span></p><p className="mt-1 text-sm leading-5 text-[#d3cedd]">{persisted.content}</p></div></div>)}{comments.map((entry, entryIndex) => <div className="flex gap-3" key={`${entry}-${entryIndex}`}><div className="grid size-9 place-items-center rounded-full bg-violet-400/15 text-[10px] font-bold text-violet-200">k</div><div><p className="text-xs font-bold">Comunidade kas <span className="ml-1 font-normal text-[#807989]">agora</span></p><p className="mt-1 text-sm leading-5 text-[#d3cedd]">{entry}</p></div></div>)}</div><div className="flex gap-2 border-t border-white/[.08] p-4"><Input value={comment} onChange={event => setComment(event.target.value)} onKeyDown={event => event.key === "Enter" && submitComment()} placeholder="Adicione um comentário" className="h-11 border-white/10 bg-white/[.045] text-sm placeholder:text-[#777183]" /><Button onClick={submitComment} aria-label="Enviar comentário" className="size-11 rounded-xl bg-violet-500 p-0 hover:bg-violet-400"><Send className="size-4" /></Button></div></section></div>}
      {supportOpen && <div className="fixed inset-0 z-40 grid place-items-center bg-black/75 p-4 backdrop-blur-sm"><section role="dialog" aria-modal="true" aria-label="Apoiar criador com Kash" className="w-full max-w-md overflow-hidden rounded-[28px] border border-violet-300/20 bg-[#16141f] shadow-[0_24px_90px_rgba(0,0,0,.55)]"><div className="relative overflow-hidden px-6 pb-5 pt-6"><div className="absolute inset-x-0 top-0 h-28 bg-[radial-gradient(ellipse_at_top,rgba(147,111,255,.38),transparent_70%)]" /><div className="relative flex items-start justify-between"><div className="grid size-11 place-items-center rounded-2xl bg-violet-300/15 text-violet-200"><Gift className="size-5" /></div><button onClick={() => setSupportOpen(false)} className="grid size-9 place-items-center rounded-xl text-[#aaa3b8] hover:bg-white/[.07] hover:text-white"><X className="size-5" /></button></div><div className="relative mt-5"><p className="text-xs font-bold uppercase tracking-[.16em] text-violet-200">Apoio direto</p><h2 className="mt-2 font-display text-2xl font-semibold tracking-[-.04em]">Envie Kash para<br />{current.creator.name}.</h2><p className="mt-2 text-sm leading-5 text-[#aaa4b8]">R$ 1,00 = 10 Kash. O criador recebe 85% deste apoio.</p></div></div><div className="border-y border-white/[.08] bg-black/15 px-6 py-5"><p className="mb-3 text-xs font-bold text-[#a9a2b7]">Escolha uma quantia</p><div className="grid grid-cols-3 gap-2">{[20, 40, 80].map(value => <button key={value} onClick={() => setAmount(value)} className={`rounded-xl border px-2 py-3 text-sm font-bold ${amount === value ? "border-violet-300/70 bg-violet-400/20 text-white" : "border-white/[.09] bg-white/[.03] text-[#b0aaba] hover:border-white/20"}`}>{value} <span className="text-[10px] font-medium">Kash</span></button>)}</div></div><div className="space-y-3 px-6 py-5"><div className="flex items-center justify-between text-xs"><span className="text-[#9790a8]">Criador recebe</span><span className="font-bold text-violet-200">{amount * 0.85} Kash</span></div><div className="flex items-center justify-between text-xs"><span className="text-[#9790a8]">Taxa kas</span><span className="font-semibold text-[#d4cfe0]">{amount * 0.15} Kash</span></div><div className="flex items-center justify-between border-t border-white/[.07] pt-3 text-xs"><span className="text-[#9790a8]">Seu saldo</span><span className="font-bold">{formatKash(walletMilli)} Kash</span></div><Button onClick={sendSupport} className="mt-2 h-12 w-full rounded-xl bg-gradient-to-r from-violet-500 to-fuchsia-500 font-bold text-white shadow-lg shadow-violet-950/40 hover:from-violet-400 hover:to-fuchsia-400"><Gift className="mr-2 size-4" /> Enviar {amount} Kash</Button></div></section></div>}
    </main>
  );
}
