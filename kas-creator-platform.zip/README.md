# kas — MVP Web/Desktop

O **kas** é uma plataforma de vídeos curtos voltada a navegadores e monitores desktop. Este MVP concentra o consumo imersivo de vídeos em uma tela de três colunas e incorpora ações sociais, apoio direto ao criador e uma carteira de moeda interna denominada **Kash**. A experiência usa uma interface escura com roxo elétrico, preto e grafite, priorizando contraste, foco no vídeo e atalhos de teclado.

## Escopo funcional

| Área | Implementação no MVP |
|---|---|
| Feed | Feed vertical 9:16, controle de reprodução, mute, navegação por botões e pelas teclas **↑**, **↓**, **Espaço** e **M**. |
| Social | Estados de curtida, comentários e compartilhamento. Curtidas, comentários e visualizações possuem contratos tRPC para persistência autenticada. |
| Criadores | Painel fixo com perfil do criador em foco, seguidores, CTA de apoio e indicadores do conteúdo. |
| Kash | Carteira, modal de apoio, cálculo explícito da divisão 85/15 e recarga via sessão de checkout. |
| Mídia | Contrato seguro para upload de avatar, thumbnail e vídeo; o armazenamento de objetos mantém os bytes e o banco guarda somente chaves, URLs e metadados. |
| Saque | Procedimento tRPC de solicitação de saque, bloqueado por KYC validado, habilitação de pagamento e mínimo de R$ 50,00. |

## Arquitetura

O projeto usa **React 19**, **Tailwind CSS 4**, **Express**, **tRPC** e **Drizzle**. O template gerenciado atual utiliza MySQL/TiDB para a execução do MVP, com o schema correspondente em `drizzle/schema.ts` e a migração em `drizzle/0001_graceful_red_hulk.sql`. O arquivo [`docs/KAS_SCHEMA_POSTGRES.sql`](docs/KAS_SCHEMA_POSTGRES.sql) é a implementação PostgreSQL completa solicitada para um ambiente de produção PostgreSQL; ele mantém as mesmas entidades e regras de integridade do domínio.

| Camada | Responsabilidade | Arquivos principais |
|---|---|---|
| Cliente | Feed, atalhos, modal Kash, estados de interação e checkout | `client/src/components/KasFeedView.tsx`, `client/src/pages/Home.tsx` |
| API | Feed, likes, comentários, visualizações, carteira, apoio, saque e mídia | `server/routers/kas.ts` |
| Domínio | Conversão, divisão financeira e validação de retenção | `shared/kash.ts` |
| Persistência | Carteiras, vídeos, eventos de visualização, interações e transações | `drizzle/schema.ts`, `server/db.ts` |
| Pagamentos | Sessão Stripe Checkout e webhook com verificação de assinatura | `server/stripe.ts`, `server/kash-products.ts` |
| Mídia | Upload e URLs seguras do armazenamento de objetos | `server/storage.ts`, `docs/ARQUITETURA_MIDIA.md` |

## Regras de negócio

| Regra | Definição implementada |
|---|---|
| Conversão | **R$ 1,00 = 10 Kash**. O código usa milésimos de Kash e centavos de BRL para evitar imprecisão de ponto flutuante. |
| Apoio | Ao enviar Kash, **85%** é atribuído ao criador e **15%** é registrado como participação da plataforma. A divisão é calculada no servidor. |
| Visualização válida | Uma view é válida apenas quando a retenção acumulada é de pelo menos **3.000 ms**. O evento é preservado para auditoria e somente views válidas incrementam o total. |
| Saque | O criador precisa estar com KYC `verified`, pagamentos habilitados e saldo disponível de no mínimo **R$ 50,00**. O valor é reservado como pendente até a confirmação do provedor de pagamento. |
| Idempotência | A compra de Kash é identificada pelo `stripePaymentIntentId`. Um webhook repetido não pode creditar a carteira duas vezes. |

> A carteira de demonstração exibida ao visitante permite validar a experiência de apoio. Operações persistentes exigem uma sessão autenticada e dados de vídeo/criador já publicados no banco.

## Instalação e execução

| Passo | Comando ou ação |
|---|---|
| Instalar dependências | `pnpm install` |
| Iniciar desenvolvimento | `pnpm dev` |
| Verificar tipos | `pnpm check` |
| Executar testes | `pnpm test` |
| Gerar migração após alterar schema | `pnpm drizzle-kit generate` |
| Aplicar migração local gerenciada | `pnpm drizzle-kit migrate` |

O ambiente requer uma `DATABASE_URL` compatível com o dialeto configurado em `drizzle.config.ts`. As chaves de autenticação, armazenamento e Stripe são injetadas pelo ambiente gerenciado; elas não devem ser colocadas em arquivos versionados. Para ativar pagamentos de teste, reivindique o sandbox Stripe em **Settings → Payment** e cadastre o endpoint `/api/stripe/webhook` no painel Stripe com o segredo de webhook configurado.

## Fluxos de integração

O método `kas.media.upload` aceita `avatar`, `thumbnail` ou `video`, valida o MIME e o limite do arquivo, gera uma chave isolada por usuário e grava os bytes no armazenamento de objetos. A API retorna somente `{ key, url, mimeType }`; a aplicação deve salvar a chave e a URL nas colunas específicas de `users` ou `videos`. O limite atual de upload por requisição é propositalmente conservador para o MVP. Para vídeos maiores em produção, deve-se adotar upload multipart diretamente para objeto assinado, validação de duração, moderação e processamento assíncrono.

Para compra de Kash, `kas.wallet.createCheckout` cria uma sessão Stripe Checkout no servidor com usuário e pacote em `metadata`. O webhook verifica a assinatura e só então chama `creditPurchasedKash`. Para recebimento, `kas.wallet.beginCreatorOnboarding` cria ou reutiliza uma conta Stripe Connect Express e retorna o link de onboarding; o evento `account.updated` atualiza a elegibilidade de KYC e pagamentos na carteira. O procedimento `kas.wallet.requestPayout` reserva o saldo, encaminha uma transferência para a conta conectada e reverte a reserva se o provedor rejeitar a criação da transferência. Uma integração Pix dedicada pode ser adicionada como provedor adicional sem alterar o ledger Kash.

## Proteções e próximos passos

O MVP já evita armazenar conteúdo de mídia, cartões ou segredos no banco. Produção requer uma camada adicional de anti-fraude: fingerprint de sessão, limitação por IP/dispositivo, deduplicação de eventos, detecção de bot, análise de padrões e fila de revisão. O onboarding Connect precisa ser reivindicado, configurado e homologado no ambiente Stripe antes de habilitar qualquer saque real.

Para uma ativação completa, os próximos incrementos são o console de upload/publicação, Stripe Connect para onboarding e Pix, moderação de conteúdo, relações de seguir, um feed ranqueado e telemetria de retenção em tempo real.

## Referências técnicas

[1] [Stripe Checkout Sessions](https://docs.stripe.com/api/checkout/sessions)

[2] [Stripe: verificação de assinatura de webhooks](https://docs.stripe.com/webhooks/signature)

[3] [PostgreSQL: constraints e integridade de dados](https://www.postgresql.org/docs/current/ddl-constraints.html)
