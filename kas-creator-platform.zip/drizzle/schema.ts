import { index, int, json, mysqlEnum, mysqlTable, text, timestamp, uniqueIndex, varchar } from "drizzle-orm/mysql-core";

/** Identidade e perfil do usuário, enriquecidos após a autenticação Manus. */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin", "creator"]).default("user").notNull(),
  handle: varchar("handle", { length: 40 }).unique(),
  avatarUrl: text("avatarUrl"),
  avatarStorageKey: varchar("avatarStorageKey", { length: 512 }),
  bio: varchar("bio", { length: 280 }),
  followerCount: int("followerCount").notNull().default(0),
  followingCount: int("followingCount").notNull().default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/** Saldos em unidades inteiras para evitar arredondamento financeiro. */
export const wallets = mysqlTable(
  "wallets",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
    brlBalanceCents: int("brlBalanceCents").notNull().default(0),
    kashMilliBalance: int("kashMilliBalance").notNull().default(0),
    pendingPayoutCents: int("pendingPayoutCents").notNull().default(0),
    kycStatus: mysqlEnum("kycStatus", ["not_started", "pending", "verified", "rejected"]).notNull().default("not_started"),
    stripeCustomerId: varchar("stripeCustomerId", { length: 255 }),
    stripeAccountId: varchar("stripeAccountId", { length: 255 }),
    payoutsEnabled: int("payoutsEnabled").notNull().default(0),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => [uniqueIndex("wallets_user_id_unique").on(table.userId)],
);

export const videos = mysqlTable(
  "videos",
  {
    id: int("id").autoincrement().primaryKey(),
    creatorId: int("creatorId").notNull().references(() => users.id, { onDelete: "cascade" }),
    title: varchar("title", { length: 140 }).notNull(),
    description: text("description"),
    hashtags: varchar("hashtags", { length: 1000 }).notNull().default(""),
    videoUrl: text("videoUrl").notNull(),
    videoStorageKey: varchar("videoStorageKey", { length: 512 }),
    thumbnailUrl: text("thumbnailUrl"),
    thumbnailStorageKey: varchar("thumbnailStorageKey", { length: 512 }),
    durationMs: int("durationMs").notNull(),
    visibility: mysqlEnum("videoVisibility", ["public", "unlisted", "private"]).notNull().default("public"),
    status: mysqlEnum("videoStatus", ["draft", "processing", "published", "rejected"]).notNull().default("draft"),
    totalViews: int("totalViews").notNull().default(0),
    totalLikes: int("totalLikes").notNull().default(0),
    averageRetentionMs: int("averageRetentionMs").notNull().default(0),
    publishedAt: timestamp("publishedAt"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => [index("videos_creator_published_idx").on(table.creatorId, table.publishedAt), index("videos_feed_idx").on(table.status, table.visibility, table.publishedAt)],
);

export const videoLikes = mysqlTable(
  "videoLikes",
  {
    id: int("id").autoincrement().primaryKey(),
    videoId: int("videoId").notNull().references(() => videos.id, { onDelete: "cascade" }),
    userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => [uniqueIndex("video_likes_video_user_unique").on(table.videoId, table.userId), index("video_likes_user_idx").on(table.userId)],
);

export const videoComments = mysqlTable(
  "videoComments",
  {
    id: int("id").autoincrement().primaryKey(),
    videoId: int("videoId").notNull().references(() => videos.id, { onDelete: "cascade" }),
    userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
    content: varchar("content", { length: 500 }).notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => [index("video_comments_video_created_idx").on(table.videoId, table.createdAt)],
);

export const videoViewEvents = mysqlTable(
  "videoViewEvents",
  {
    id: int("id").autoincrement().primaryKey(),
    videoId: int("videoId").notNull().references(() => videos.id, { onDelete: "cascade" }),
    viewerUserId: int("viewerUserId").references(() => users.id, { onDelete: "set null" }),
    retentionMs: int("retentionMs").notNull(),
    isValid: int("isValid").notNull().default(0),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => [index("video_view_events_video_created_idx").on(table.videoId, table.createdAt), index("video_view_events_viewer_idx").on(table.viewerUserId)],
);

export const transactions = mysqlTable(
  "transactions",
  {
    id: int("id").autoincrement().primaryKey(),
    type: mysqlEnum("transactionType", ["kash_purchase", "creator_support", "creator_earning", "payout_request", "payout_completed", "refund", "subscription_purchase", "exclusive_unlock"]).notNull(),
    status: mysqlEnum("transactionStatus", ["pending", "completed", "failed", "cancelled"]).notNull().default("pending"),
    senderWalletId: int("senderWalletId").references(() => wallets.id, { onDelete: "set null" }),
    receiverWalletId: int("receiverWalletId").references(() => wallets.id, { onDelete: "set null" }),
    videoId: int("videoId").references(() => videos.id, { onDelete: "set null" }),
    kashMilliAmount: int("kashMilliAmount").notNull().default(0),
    creatorKashMilli: int("creatorKashMilli").notNull().default(0),
    platformKashMilli: int("platformKashMilli").notNull().default(0),
    brlCentsAmount: int("brlCentsAmount").notNull().default(0),
    stripePaymentIntentId: varchar("stripePaymentIntentId", { length: 255 }),
    stripePayoutId: varchar("stripePayoutId", { length: 255 }),
    metadata: json("metadata"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => [
    uniqueIndex("transactions_payment_intent_unique").on(table.stripePaymentIntentId),
    index("transactions_sender_created_idx").on(table.senderWalletId, table.createdAt),
    index("transactions_receiver_created_idx").on(table.receiverWalletId, table.createdAt),
    index("transactions_type_status_idx").on(table.type, table.status),
  ],
);


/** Relações sociais com idempotência por par de usuários. */
export const follows = mysqlTable(
  "follows",
  {
    id: int("id").autoincrement().primaryKey(),
    followerId: int("followerId").notNull().references(() => users.id, { onDelete: "cascade" }),
    followingId: int("followingId").notNull().references(() => users.id, { onDelete: "cascade" }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => [uniqueIndex("follows_pair_unique").on(table.followerId, table.followingId), index("follows_follower_idx").on(table.followerId), index("follows_following_idx").on(table.followingId)],
);

export const liveRooms = mysqlTable(
  "liveRooms",
  {
    id: int("id").autoincrement().primaryKey(),
    hostId: int("hostId").notNull().references(() => users.id, { onDelete: "cascade" }),
    title: varchar("title", { length: 140 }).notNull(),
    category: varchar("category", { length: 60 }).notNull(),
    coverUrl: text("coverUrl"),
    status: mysqlEnum("liveStatus", ["scheduled", "live", "ended"]).notNull().default("scheduled"),
    viewerCount: int("viewerCount").notNull().default(0),
    goalKashMilli: int("goalKashMilli").notNull().default(0),
    raisedKashMilli: int("raisedKashMilli").notNull().default(0),
    startsAt: timestamp("startsAt"),
    endsAt: timestamp("endsAt"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => [index("live_rooms_status_idx").on(table.status, table.startsAt), index("live_rooms_host_idx").on(table.hostId)],
);

export const liveMessages = mysqlTable(
  "liveMessages",
  {
    id: int("id").autoincrement().primaryKey(),
    roomId: int("roomId").notNull().references(() => liveRooms.id, { onDelete: "cascade" }),
    userId: int("userId").references(() => users.id, { onDelete: "set null" }),
    body: varchar("body", { length: 280 }).notNull(),
    messageType: mysqlEnum("liveMessageType", ["chat", "system", "gift"]).notNull().default("chat"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => [index("live_messages_room_created_idx").on(table.roomId, table.createdAt)],
);

export const liveGifts = mysqlTable(
  "liveGifts",
  {
    id: int("id").autoincrement().primaryKey(),
    roomId: int("roomId").notNull().references(() => liveRooms.id, { onDelete: "cascade" }),
    senderId: int("senderId").notNull().references(() => users.id, { onDelete: "cascade" }),
    creatorId: int("creatorId").notNull().references(() => users.id, { onDelete: "cascade" }),
    giftName: varchar("giftName", { length: 60 }).notNull(),
    kashMilli: int("kashMilli").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => [index("live_gifts_room_created_idx").on(table.roomId, table.createdAt), index("live_gifts_creator_idx").on(table.creatorId)],
);

export const communities = mysqlTable(
  "communities",
  {
    id: int("id").autoincrement().primaryKey(),
    creatorId: int("creatorId").notNull().references(() => users.id, { onDelete: "cascade" }),
    name: varchar("name", { length: 80 }).notNull(),
    handle: varchar("handle", { length: 60 }).notNull().unique(),
    description: varchar("description", { length: 280 }).notNull(),
    accent: varchar("accent", { length: 20 }).notNull().default("lime"),
    monthlyPriceCents: int("monthlyPriceCents").notNull().default(0),
    memberCount: int("memberCount").notNull().default(0),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => [index("communities_creator_idx").on(table.creatorId)],
);

export const communityMembers = mysqlTable(
  "communityMembers",
  {
    id: int("id").autoincrement().primaryKey(),
    communityId: int("communityId").notNull().references(() => communities.id, { onDelete: "cascade" }),
    userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
    tier: mysqlEnum("communityTier", ["visitor", "inner", "circle"]).notNull().default("inner"),
    contributionKashMilli: int("contributionKashMilli").notNull().default(0),
    joinedAt: timestamp("joinedAt").defaultNow().notNull(),
  },
  table => [uniqueIndex("community_members_pair_unique").on(table.communityId, table.userId), index("community_members_user_idx").on(table.userId)],
);

export const communityMissions = mysqlTable(
  "communityMissions",
  {
    id: int("id").autoincrement().primaryKey(),
    communityId: int("communityId").notNull().references(() => communities.id, { onDelete: "cascade" }),
    title: varchar("title", { length: 120 }).notNull(),
    description: varchar("description", { length: 240 }).notNull(),
    targetValue: int("targetValue").notNull(),
    currentValue: int("currentValue").notNull().default(0),
    rewardKashMilli: int("rewardKashMilli").notNull().default(0),
    status: mysqlEnum("missionStatus", ["active", "completed"]).notNull().default("active"),
    dueAt: timestamp("dueAt"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => [index("community_missions_status_idx").on(table.communityId, table.status)],
);

export const creatorContent = mysqlTable(
  "creatorContent",
  {
    id: int("id").autoincrement().primaryKey(),
    creatorId: int("creatorId").notNull().references(() => users.id, { onDelete: "cascade" }),
    videoId: int("videoId").references(() => videos.id, { onDelete: "set null" }),
    title: varchar("title", { length: 140 }).notNull(),
    teaser: varchar("teaser", { length: 280 }).notNull(),
    accessType: mysqlEnum("contentAccessType", ["public", "community", "paid"]).notNull().default("public"),
    priceCents: int("priceCents").notNull().default(0),
    stripeProductId: varchar("stripeProductId", { length: 255 }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => [index("creator_content_creator_idx").on(table.creatorId, table.createdAt), index("creator_content_access_idx").on(table.accessType, table.createdAt)],
);

export const communitySubscriptions = mysqlTable(
  "communitySubscriptions",
  {
    id: int("id").autoincrement().primaryKey(),
    communityId: int("communityId").notNull().references(() => communities.id, { onDelete: "cascade" }),
    userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
    stripeSubscriptionId: varchar("stripeSubscriptionId", { length: 255 }).notNull().unique(),
    status: mysqlEnum("subscriptionStatus", ["active", "past_due", "canceled", "incomplete"]).notNull().default("incomplete"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => [uniqueIndex("community_subscriptions_pair_unique").on(table.communityId, table.userId), index("community_subscriptions_user_idx").on(table.userId)],
);

export const notifications = mysqlTable(
  "notifications",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
    type: mysqlEnum("notificationType", ["live_started", "goal_reached", "exclusive_post", "system"]).notNull(),
    title: varchar("title", { length: 120 }).notNull(),
    body: varchar("body", { length: 240 }).notNull(),
    href: varchar("href", { length: 255 }),
    isRead: int("isRead").notNull().default(0),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => [index("notifications_user_created_idx").on(table.userId, table.createdAt)],
);

export const reports = mysqlTable(
  "reports",
  {
    id: int("id").autoincrement().primaryKey(),
    reporterId: int("reporterId").notNull().references(() => users.id, { onDelete: "cascade" }),
    targetUserId: int("targetUserId").references(() => users.id, { onDelete: "set null" }),
    videoId: int("videoId").references(() => videos.id, { onDelete: "set null" }),
    liveRoomId: int("liveRoomId").references(() => liveRooms.id, { onDelete: "set null" }),
    reason: mysqlEnum("reportReason", ["spam", "harassment", "unsafe", "copyright", "other"]).notNull(),
    details: varchar("details", { length: 500 }),
    status: mysqlEnum("reportStatus", ["open", "reviewing", "resolved"]).notNull().default("open"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => [index("reports_status_idx").on(table.status, table.createdAt), index("reports_reporter_idx").on(table.reporterId)],
);

export const blocks = mysqlTable(
  "blocks",
  {
    id: int("id").autoincrement().primaryKey(),
    blockerId: int("blockerId").notNull().references(() => users.id, { onDelete: "cascade" }),
    blockedUserId: int("blockedUserId").notNull().references(() => users.id, { onDelete: "cascade" }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => [uniqueIndex("blocks_pair_unique").on(table.blockerId, table.blockedUserId)],
);

export const creatorGoals = mysqlTable(
  "creatorGoals",
  {
    id: int("id").autoincrement().primaryKey(),
    creatorId: int("creatorId").notNull().references(() => users.id, { onDelete: "cascade" }),
    title: varchar("title", { length: 120 }).notNull(),
    currentValue: int("currentValue").notNull().default(0),
    targetValue: int("targetValue").notNull(),
    unit: mysqlEnum("goalUnit", ["views", "engagement", "supporters", "posts"]).notNull(),
    weekStart: timestamp("weekStart").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => [index("creator_goals_week_idx").on(table.creatorId, table.weekStart)],
);

export type Follow = typeof follows.$inferSelect;
export type LiveRoom = typeof liveRooms.$inferSelect;
export type Community = typeof communities.$inferSelect;
export type CreatorContent = typeof creatorContent.$inferSelect;
