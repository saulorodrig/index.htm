CREATE TABLE `blocks` (
	`id` int AUTO_INCREMENT NOT NULL,
	`blockerId` int NOT NULL,
	`blockedUserId` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `blocks_id` PRIMARY KEY(`id`),
	CONSTRAINT `blocks_pair_unique` UNIQUE(`blockerId`,`blockedUserId`)
);
--> statement-breakpoint
CREATE TABLE `communities` (
	`id` int AUTO_INCREMENT NOT NULL,
	`creatorId` int NOT NULL,
	`name` varchar(80) NOT NULL,
	`handle` varchar(60) NOT NULL,
	`description` varchar(280) NOT NULL,
	`accent` varchar(20) NOT NULL DEFAULT 'lime',
	`monthlyPriceCents` int NOT NULL DEFAULT 0,
	`memberCount` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `communities_id` PRIMARY KEY(`id`),
	CONSTRAINT `communities_handle_unique` UNIQUE(`handle`)
);
--> statement-breakpoint
CREATE TABLE `communityMembers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`communityId` int NOT NULL,
	`userId` int NOT NULL,
	`communityTier` enum('visitor','inner','circle') NOT NULL DEFAULT 'inner',
	`contributionKashMilli` int NOT NULL DEFAULT 0,
	`joinedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `communityMembers_id` PRIMARY KEY(`id`),
	CONSTRAINT `community_members_pair_unique` UNIQUE(`communityId`,`userId`)
);
--> statement-breakpoint
CREATE TABLE `communityMissions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`communityId` int NOT NULL,
	`title` varchar(120) NOT NULL,
	`description` varchar(240) NOT NULL,
	`targetValue` int NOT NULL,
	`currentValue` int NOT NULL DEFAULT 0,
	`rewardKashMilli` int NOT NULL DEFAULT 0,
	`missionStatus` enum('active','completed') NOT NULL DEFAULT 'active',
	`dueAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `communityMissions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `communitySubscriptions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`communityId` int NOT NULL,
	`userId` int NOT NULL,
	`stripeSubscriptionId` varchar(255) NOT NULL,
	`subscriptionStatus` enum('active','past_due','canceled','incomplete') NOT NULL DEFAULT 'incomplete',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `communitySubscriptions_id` PRIMARY KEY(`id`),
	CONSTRAINT `communitySubscriptions_stripeSubscriptionId_unique` UNIQUE(`stripeSubscriptionId`),
	CONSTRAINT `community_subscriptions_pair_unique` UNIQUE(`communityId`,`userId`)
);
--> statement-breakpoint
CREATE TABLE `creatorContent` (
	`id` int AUTO_INCREMENT NOT NULL,
	`creatorId` int NOT NULL,
	`videoId` int,
	`title` varchar(140) NOT NULL,
	`teaser` varchar(280) NOT NULL,
	`contentAccessType` enum('public','community','paid') NOT NULL DEFAULT 'public',
	`priceCents` int NOT NULL DEFAULT 0,
	`stripeProductId` varchar(255),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `creatorContent_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `creatorGoals` (
	`id` int AUTO_INCREMENT NOT NULL,
	`creatorId` int NOT NULL,
	`title` varchar(120) NOT NULL,
	`currentValue` int NOT NULL DEFAULT 0,
	`targetValue` int NOT NULL,
	`goalUnit` enum('views','engagement','supporters','posts') NOT NULL,
	`weekStart` timestamp NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `creatorGoals_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `follows` (
	`id` int AUTO_INCREMENT NOT NULL,
	`followerId` int NOT NULL,
	`followingId` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `follows_id` PRIMARY KEY(`id`),
	CONSTRAINT `follows_pair_unique` UNIQUE(`followerId`,`followingId`)
);
--> statement-breakpoint
CREATE TABLE `liveGifts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`roomId` int NOT NULL,
	`senderId` int NOT NULL,
	`creatorId` int NOT NULL,
	`giftName` varchar(60) NOT NULL,
	`kashMilli` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `liveGifts_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `liveMessages` (
	`id` int AUTO_INCREMENT NOT NULL,
	`roomId` int NOT NULL,
	`userId` int,
	`body` varchar(280) NOT NULL,
	`liveMessageType` enum('chat','system','gift') NOT NULL DEFAULT 'chat',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `liveMessages_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `liveRooms` (
	`id` int AUTO_INCREMENT NOT NULL,
	`hostId` int NOT NULL,
	`title` varchar(140) NOT NULL,
	`category` varchar(60) NOT NULL,
	`coverUrl` text,
	`liveStatus` enum('scheduled','live','ended') NOT NULL DEFAULT 'scheduled',
	`viewerCount` int NOT NULL DEFAULT 0,
	`goalKashMilli` int NOT NULL DEFAULT 0,
	`raisedKashMilli` int NOT NULL DEFAULT 0,
	`startsAt` timestamp,
	`endsAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `liveRooms_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `notifications` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`notificationType` enum('live_started','goal_reached','exclusive_post','system') NOT NULL,
	`title` varchar(120) NOT NULL,
	`body` varchar(240) NOT NULL,
	`href` varchar(255),
	`isRead` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `notifications_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `reports` (
	`id` int AUTO_INCREMENT NOT NULL,
	`reporterId` int NOT NULL,
	`targetUserId` int,
	`videoId` int,
	`liveRoomId` int,
	`reportReason` enum('spam','harassment','unsafe','copyright','other') NOT NULL,
	`details` varchar(500),
	`reportStatus` enum('open','reviewing','resolved') NOT NULL DEFAULT 'open',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `reports_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `blocks` ADD CONSTRAINT `blocks_blockerId_users_id_fk` FOREIGN KEY (`blockerId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `blocks` ADD CONSTRAINT `blocks_blockedUserId_users_id_fk` FOREIGN KEY (`blockedUserId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `communities` ADD CONSTRAINT `communities_creatorId_users_id_fk` FOREIGN KEY (`creatorId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `communityMembers` ADD CONSTRAINT `communityMembers_communityId_communities_id_fk` FOREIGN KEY (`communityId`) REFERENCES `communities`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `communityMembers` ADD CONSTRAINT `communityMembers_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `communityMissions` ADD CONSTRAINT `communityMissions_communityId_communities_id_fk` FOREIGN KEY (`communityId`) REFERENCES `communities`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `communitySubscriptions` ADD CONSTRAINT `communitySubscriptions_communityId_communities_id_fk` FOREIGN KEY (`communityId`) REFERENCES `communities`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `communitySubscriptions` ADD CONSTRAINT `communitySubscriptions_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `creatorContent` ADD CONSTRAINT `creatorContent_creatorId_users_id_fk` FOREIGN KEY (`creatorId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `creatorContent` ADD CONSTRAINT `creatorContent_videoId_videos_id_fk` FOREIGN KEY (`videoId`) REFERENCES `videos`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `creatorGoals` ADD CONSTRAINT `creatorGoals_creatorId_users_id_fk` FOREIGN KEY (`creatorId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `follows` ADD CONSTRAINT `follows_followerId_users_id_fk` FOREIGN KEY (`followerId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `follows` ADD CONSTRAINT `follows_followingId_users_id_fk` FOREIGN KEY (`followingId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `liveGifts` ADD CONSTRAINT `liveGifts_roomId_liveRooms_id_fk` FOREIGN KEY (`roomId`) REFERENCES `liveRooms`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `liveGifts` ADD CONSTRAINT `liveGifts_senderId_users_id_fk` FOREIGN KEY (`senderId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `liveGifts` ADD CONSTRAINT `liveGifts_creatorId_users_id_fk` FOREIGN KEY (`creatorId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `liveMessages` ADD CONSTRAINT `liveMessages_roomId_liveRooms_id_fk` FOREIGN KEY (`roomId`) REFERENCES `liveRooms`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `liveMessages` ADD CONSTRAINT `liveMessages_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `liveRooms` ADD CONSTRAINT `liveRooms_hostId_users_id_fk` FOREIGN KEY (`hostId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `notifications` ADD CONSTRAINT `notifications_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `reports` ADD CONSTRAINT `reports_reporterId_users_id_fk` FOREIGN KEY (`reporterId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `reports` ADD CONSTRAINT `reports_targetUserId_users_id_fk` FOREIGN KEY (`targetUserId`) REFERENCES `users`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `reports` ADD CONSTRAINT `reports_videoId_videos_id_fk` FOREIGN KEY (`videoId`) REFERENCES `videos`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `reports` ADD CONSTRAINT `reports_liveRoomId_liveRooms_id_fk` FOREIGN KEY (`liveRoomId`) REFERENCES `liveRooms`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `communities_creator_idx` ON `communities` (`creatorId`);--> statement-breakpoint
CREATE INDEX `community_members_user_idx` ON `communityMembers` (`userId`);--> statement-breakpoint
CREATE INDEX `community_missions_status_idx` ON `communityMissions` (`communityId`,`missionStatus`);--> statement-breakpoint
CREATE INDEX `community_subscriptions_user_idx` ON `communitySubscriptions` (`userId`);--> statement-breakpoint
CREATE INDEX `creator_content_creator_idx` ON `creatorContent` (`creatorId`,`createdAt`);--> statement-breakpoint
CREATE INDEX `creator_content_access_idx` ON `creatorContent` (`contentAccessType`,`createdAt`);--> statement-breakpoint
CREATE INDEX `creator_goals_week_idx` ON `creatorGoals` (`creatorId`,`weekStart`);--> statement-breakpoint
CREATE INDEX `follows_follower_idx` ON `follows` (`followerId`);--> statement-breakpoint
CREATE INDEX `follows_following_idx` ON `follows` (`followingId`);--> statement-breakpoint
CREATE INDEX `live_gifts_room_created_idx` ON `liveGifts` (`roomId`,`createdAt`);--> statement-breakpoint
CREATE INDEX `live_gifts_creator_idx` ON `liveGifts` (`creatorId`);--> statement-breakpoint
CREATE INDEX `live_messages_room_created_idx` ON `liveMessages` (`roomId`,`createdAt`);--> statement-breakpoint
CREATE INDEX `live_rooms_status_idx` ON `liveRooms` (`liveStatus`,`startsAt`);--> statement-breakpoint
CREATE INDEX `live_rooms_host_idx` ON `liveRooms` (`hostId`);--> statement-breakpoint
CREATE INDEX `notifications_user_created_idx` ON `notifications` (`userId`,`createdAt`);--> statement-breakpoint
CREATE INDEX `reports_status_idx` ON `reports` (`reportStatus`,`createdAt`);--> statement-breakpoint
CREATE INDEX `reports_reporter_idx` ON `reports` (`reporterId`);