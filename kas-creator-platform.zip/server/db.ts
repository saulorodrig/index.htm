import { and, desc, eq, like, or, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  type InsertUser,
  blocks,
  communities,
  communityMissions,
  creatorContent,
  creatorGoals,
  follows,
  liveGifts,
  liveMessages,
  liveRooms,
  notifications,
  reports,
  transactions,
  users,
  videoComments,
  videoLikes,
  videoViewEvents,
  videos,
  wallets,
} from "../drizzle/schema";
import { MINIMUM_WITHDRAWAL_CENTS, calculateKashSplit, isValidViewRetention, kashMilliToBrlCents } from "../shared/kash";
import { assertCreatorSupport, assertPayoutEligibility, shouldCreditPaymentIntent } from "../shared/kash-flow";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;

  const values: InsertUser = { openId: user.openId, lastSignedIn: user.lastSignedIn ?? new Date() };
  const updateSet: Record<string, unknown> = { lastSignedIn: values.lastSignedIn };
  const textFields = ["name", "email", "loginMethod"] as const;
  for (const field of textFields) {
    if (user[field] !== undefined) {
      values[field] = user[field] ?? null;
      updateSet[field] = user[field] ?? null;
    }
  }
  values.role = user.role ?? (user.openId === ENV.ownerOpenId ? "admin" : "user");
  updateSet.role = values.role;
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

async function ensureWallet(userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  await db.insert(wallets).values({ userId }).onDuplicateKeyUpdate({ set: { updatedAt: new Date() } });
  const [wallet] = await db.select().from(wallets).where(eq(wallets.userId, userId)).limit(1);
  return wallet;
}

export async function getWalletByUserId(userId: number) {
  return ensureWallet(userId);
}

export async function getFeed(limit: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select({ video: videos, creator: users })
    .from(videos)
    .innerJoin(users, eq(videos.creatorId, users.id))
    .where(and(eq(videos.status, "published"), eq(videos.visibility, "public")))
    .orderBy(desc(videos.publishedAt))
    .limit(limit);
}

export function normalizeHashtags(value: string) {
  const matches = value.match(/#[^\s#]+/g) ?? [];
  return Array.from(new Set(matches.map(tag => tag.slice(1).normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-zA-Z0-9_-]/g, "").toLowerCase()).filter(Boolean))).join(",");
}

export async function searchDiscovery(input: { term: string; limit?: number }) {
  const db = await getDb();
  if (!db) return [];
  const term = input.term.trim().toLowerCase().replace(/^#/, "").replace(/^@/, "");
  if (!term) return [];
  const pattern = `%${term}%`;
  return db.select({ video: videos, creator: users }).from(videos).innerJoin(users, eq(videos.creatorId, users.id)).where(and(eq(videos.status, "published"), eq(videos.visibility, "public"), or(like(videos.title, pattern), like(videos.description, pattern), like(videos.hashtags, pattern), like(users.name, pattern), like(users.handle, pattern)))).orderBy(desc(videos.publishedAt)).limit(input.limit ?? 20);
}

export async function toggleVideoLike(input: { videoId: number; userId: number }) {
  const db = await getDb();
  if (!db) return { liked: false, totalLikes: 0 };
  const [existing] = await db.select().from(videoLikes).where(and(eq(videoLikes.videoId, input.videoId), eq(videoLikes.userId, input.userId))).limit(1);
  if (existing) {
    await db.delete(videoLikes).where(eq(videoLikes.id, existing.id));
    await db.update(videos).set({ totalLikes: sql`GREATEST(${videos.totalLikes} - 1, 0)` }).where(eq(videos.id, input.videoId));
  } else {
    await db.insert(videoLikes).values(input);
    await db.update(videos).set({ totalLikes: sql`${videos.totalLikes} + 1` }).where(eq(videos.id, input.videoId));
  }
  const [video] = await db.select({ totalLikes: videos.totalLikes }).from(videos).where(eq(videos.id, input.videoId)).limit(1);
  return { liked: !existing, totalLikes: video?.totalLikes ?? 0 };
}

export async function recordView(input: { videoId: number; viewerUserId: number | null; retainedMs: number }) {
  const db = await getDb();
  const isValid = isValidViewRetention(input.retainedMs);
  if (!db) return { isValid };
  await db.insert(videoViewEvents).values({
    videoId: input.videoId,
    viewerUserId: input.viewerUserId,
    retentionMs: input.retainedMs,
    isValid: isValid ? 1 : 0,
  });
  if (isValid) await db.update(videos).set({ totalViews: sql`${videos.totalViews} + 1` }).where(eq(videos.id, input.videoId));
  return { isValid };
}

export async function getCommentsForVideo(videoId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select({ comment: videoComments, author: users }).from(videoComments).innerJoin(users, eq(videoComments.userId, users.id)).where(eq(videoComments.videoId, videoId)).orderBy(desc(videoComments.createdAt)).limit(50);
}

export async function createComment(input: { videoId: number; userId: number; content: string }) {
  const db = await getDb();
  if (!db) return undefined;
  await db.insert(videoComments).values(input);
  return getCommentsForVideo(input.videoId);
}

export async function supportCreator(input: { senderUserId: number; creatorUserId: number; videoId?: number; kashMilli: number }) {
  const db = await getDb();
  if (!db) throw new Error("Banco de dados indisponível.");
  const [senderWallet, creatorWallet] = await Promise.all([ensureWallet(input.senderUserId), ensureWallet(input.creatorUserId)]);
  if (!senderWallet || !creatorWallet) throw new Error("Carteira indisponível.");
  assertCreatorSupport({ senderUserId: input.senderUserId, creatorUserId: input.creatorUserId, senderKashMilli: senderWallet.kashMilliBalance, kashMilli: input.kashMilli });
  const split = calculateKashSplit(input.kashMilli);
  const creatorBrlCents = kashMilliToBrlCents(split.creatorKashMilli);
  await db.transaction(async tx => {
    await tx.update(wallets).set({ kashMilliBalance: sql`${wallets.kashMilliBalance} - ${input.kashMilli}` }).where(eq(wallets.id, senderWallet.id));
    await tx.update(wallets).set({ kashMilliBalance: sql`${wallets.kashMilliBalance} + ${split.creatorKashMilli}`, brlBalanceCents: sql`${wallets.brlBalanceCents} + ${creatorBrlCents}` }).where(eq(wallets.id, creatorWallet.id));
    await tx.insert(transactions).values({ type: "creator_support", status: "completed", senderWalletId: senderWallet.id, receiverWalletId: creatorWallet.id, videoId: input.videoId, kashMilliAmount: input.kashMilli, creatorKashMilli: split.creatorKashMilli, platformKashMilli: split.platformKashMilli });
  });
  return { ...split, creatorBrlCents, remainingKashMilli: senderWallet.kashMilliBalance - input.kashMilli };
}

export async function sendLiveGift(input: { senderUserId: number; creatorUserId: number; roomId: number; giftName: string; kashMilli: number }) {
  const db = await getDb();
  if (!db) throw new Error("Banco de dados indisponível.");
  const [senderWallet, creatorWallet] = await Promise.all([ensureWallet(input.senderUserId), ensureWallet(input.creatorUserId)]);
  if (!senderWallet || !creatorWallet) throw new Error("Carteira indisponível.");
  assertCreatorSupport({ senderUserId: input.senderUserId, creatorUserId: input.creatorUserId, senderKashMilli: senderWallet.kashMilliBalance, kashMilli: input.kashMilli });
  const split = calculateKashSplit(input.kashMilli);
  const creatorBrlCents = kashMilliToBrlCents(split.creatorKashMilli);
  await db.transaction(async tx => {
    await tx.update(wallets).set({ kashMilliBalance: sql`${wallets.kashMilliBalance} - ${input.kashMilli}` }).where(eq(wallets.id, senderWallet.id));
    await tx.update(wallets).set({ kashMilliBalance: sql`${wallets.kashMilliBalance} + ${split.creatorKashMilli}`, brlBalanceCents: sql`${wallets.brlBalanceCents} + ${creatorBrlCents}` }).where(eq(wallets.id, creatorWallet.id));
    await tx.insert(transactions).values({ type: "creator_support", status: "completed", senderWalletId: senderWallet.id, receiverWalletId: creatorWallet.id, kashMilliAmount: input.kashMilli, creatorKashMilli: split.creatorKashMilli, platformKashMilli: split.platformKashMilli, metadata: { giftName: input.giftName, roomId: input.roomId } });
    await tx.insert(liveGifts).values({ roomId: input.roomId, senderId: input.senderUserId, creatorId: input.creatorUserId, giftName: input.giftName, kashMilli: input.kashMilli });
    await tx.insert(liveMessages).values({ roomId: input.roomId, userId: input.senderUserId, body: `${input.giftName} enviado para a sala`, messageType: "gift" });
  });
  return { ...split, creatorBrlCents, remainingKashMilli: senderWallet.kashMilliBalance - input.kashMilli, giftName: input.giftName };
}

export async function creditPurchasedKash(input: { userId: number; kashMilli: number; brlCents: number; stripePaymentIntentId: string }) {
  const db = await getDb();
  if (!db) throw new Error("Banco de dados indisponível.");
  const wallet = await ensureWallet(input.userId);
  if (!wallet) throw new Error("Carteira indisponível.");
  const [existing] = await db.select({ id: transactions.id }).from(transactions).where(eq(transactions.stripePaymentIntentId, input.stripePaymentIntentId)).limit(1);
  if (!shouldCreditPaymentIntent(existing?.id)) return { credited: false };
  await db.transaction(async tx => {
    await tx.update(wallets).set({ kashMilliBalance: sql`${wallets.kashMilliBalance} + ${input.kashMilli}` }).where(eq(wallets.id, wallet.id));
    await tx.insert(transactions).values({ type: "kash_purchase", status: "completed", receiverWalletId: wallet.id, kashMilliAmount: input.kashMilli, brlCentsAmount: input.brlCents, stripePaymentIntentId: input.stripePaymentIntentId });
  });
  return { credited: true };
}

export async function requestCreatorPayout(input: { userId: number; brlCents: number }) {
  const db = await getDb();
  if (!db) throw new Error("Banco de dados indisponível.");
  const wallet = await ensureWallet(input.userId);
  if (!wallet) throw new Error("Carteira indisponível.");
  assertPayoutEligibility(wallet, input.brlCents);

  const transactionId = await db.transaction(async tx => {
    await tx.update(wallets).set({ brlBalanceCents: sql`${wallets.brlBalanceCents} - ${input.brlCents}`, pendingPayoutCents: sql`${wallets.pendingPayoutCents} + ${input.brlCents}` }).where(eq(wallets.id, wallet.id));
    const [created] = await tx.insert(transactions).values({ type: "payout_request", status: "pending", senderWalletId: wallet.id, brlCentsAmount: input.brlCents }).$returningId();
    return created?.id;
  });
  if (!transactionId) throw new Error("Não foi possível criar a solicitação de saque.");
  return { status: "pending" as const, brlCents: input.brlCents, transactionId, stripeAccountId: wallet.stripeAccountId! };
}

export async function markPayoutSubmitted(input: { transactionId: number; providerTransferId: string }) {
  const db = await getDb();
  if (!db) throw new Error("Banco de dados indisponível.");
  await db.update(transactions).set({ status: "completed", stripePayoutId: input.providerTransferId }).where(eq(transactions.id, input.transactionId));
}

export async function failPayoutRequest(input: { transactionId: number; providerTransferId?: string }) {
  const db = await getDb();
  if (!db) return;
  const [transaction] = await db.select().from(transactions).where(eq(transactions.id, input.transactionId)).limit(1);
  if (!transaction || transaction.status !== "pending" || !transaction.senderWalletId) return;
  await db.transaction(async tx => {
    await tx.update(wallets).set({ brlBalanceCents: sql`${wallets.brlBalanceCents} + ${transaction.brlCentsAmount}`, pendingPayoutCents: sql`GREATEST(${wallets.pendingPayoutCents} - ${transaction.brlCentsAmount}, 0)` }).where(eq(wallets.id, transaction.senderWalletId!));
    await tx.update(transactions).set({ status: "failed", stripePayoutId: input.providerTransferId }).where(eq(transactions.id, input.transactionId));
  });
}

export async function storeStripeConnectedAccount(input: { userId: number; stripeAccountId: string }) {
  const wallet = await ensureWallet(input.userId);
  const db = await getDb();
  if (!wallet || !db) throw new Error("Carteira indisponível.");
  await db.update(wallets).set({ stripeAccountId: input.stripeAccountId, kycStatus: "pending" }).where(eq(wallets.id, wallet.id));
}

export async function syncStripeConnectedAccount(input: { stripeAccountId: string; payoutsEnabled: boolean; requirementsPending: boolean }) {
  const db = await getDb();
  if (!db) return;
  await db.update(wallets).set({ payoutsEnabled: input.payoutsEnabled ? 1 : 0, kycStatus: input.payoutsEnabled ? "verified" : input.requirementsPending ? "pending" : "rejected" }).where(eq(wallets.stripeAccountId, input.stripeAccountId));
}


export async function toggleFollow(input: { followerId: number; followingId: number }) {
  const db = await getDb();
  if (!db) return { following: false };
  const [existing] = await db.select().from(follows).where(and(eq(follows.followerId, input.followerId), eq(follows.followingId, input.followingId))).limit(1);
  if (existing) {
    await db.delete(follows).where(eq(follows.id, existing.id));
    await db.update(users).set({ followingCount: sql`GREATEST(${users.followingCount} - 1, 0)` }).where(eq(users.id, input.followerId));
    await db.update(users).set({ followerCount: sql`GREATEST(${users.followerCount} - 1, 0)` }).where(eq(users.id, input.followingId));
    return { following: false };
  }
  await db.insert(follows).values(input);
  await db.update(users).set({ followingCount: sql`${users.followingCount} + 1` }).where(eq(users.id, input.followerId));
  await db.update(users).set({ followerCount: sql`${users.followerCount} + 1` }).where(eq(users.id, input.followingId));
  return { following: true };
}

export async function getLiveRooms(limit = 10) {
  const db = await getDb();
  if (!db) return [];
  return db.select({ room: liveRooms, host: users }).from(liveRooms).innerJoin(users, eq(liveRooms.hostId, users.id)).where(eq(liveRooms.status, "live")).orderBy(desc(liveRooms.viewerCount)).limit(limit);
}

export async function getLiveMessages(roomId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select({ message: liveMessages, author: users }).from(liveMessages).leftJoin(users, eq(liveMessages.userId, users.id)).where(eq(liveMessages.roomId, roomId)).orderBy(desc(liveMessages.createdAt)).limit(80);
}

export async function createLiveMessage(input: { roomId: number; userId: number; body: string }) {
  const db = await getDb();
  if (!db) return undefined;
  await db.insert(liveMessages).values({ ...input, messageType: "chat" });
  return getLiveMessages(input.roomId);
}

export async function getCommunities(limit = 10) {
  const db = await getDb();
  if (!db) return [];
  return db.select({ community: communities, creator: users }).from(communities).innerJoin(users, eq(communities.creatorId, users.id)).orderBy(desc(communities.memberCount)).limit(limit);
}

export async function getCommunityMissions(communityId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(communityMissions).where(eq(communityMissions.communityId, communityId)).orderBy(desc(communityMissions.createdAt)).limit(20);
}

export async function getNotificationsForUser(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(notifications).where(eq(notifications.userId, userId)).orderBy(desc(notifications.createdAt)).limit(30);
}

export async function markNotificationsRead(userId: number) {
  const db = await getDb();
  if (!db) return { success: false };
  await db.update(notifications).set({ isRead: 1 }).where(eq(notifications.userId, userId));
  return { success: true };
}

export async function getWalletLedger(userId: number) {
  const db = await getDb();
  if (!db) return [];
  const wallet = await ensureWallet(userId);
  if (!wallet) return [];
  return db.select().from(transactions).where(or(eq(transactions.senderWalletId, wallet.id), eq(transactions.receiverWalletId, wallet.id))).orderBy(desc(transactions.createdAt)).limit(50);
}

export async function getCreatorStudioSummary(userId: number) {
  const db = await getDb();
  if (!db) return { totalViews: 0, totalLikes: 0, publishedPosts: 0, estimatedCents: 0, goals: [] };
  const creatorVideos = await db.select({ views: videos.totalViews, likes: videos.totalLikes }).from(videos).where(eq(videos.creatorId, userId));
  const content = await db.select().from(creatorContent).where(eq(creatorContent.creatorId, userId)).orderBy(desc(creatorContent.createdAt)).limit(20);
  const wallet = await ensureWallet(userId);
  const goals = await db.select().from(creatorGoals).where(eq(creatorGoals.creatorId, userId)).orderBy(desc(creatorGoals.weekStart)).limit(10);
  return { totalViews: creatorVideos.reduce((sum, item) => sum + item.views, 0), totalLikes: creatorVideos.reduce((sum, item) => sum + item.likes, 0), publishedPosts: creatorVideos.length + content.length, estimatedCents: wallet?.brlBalanceCents ?? 0, goals, content };
}

export async function createCreatorVideo(input: { creatorId: number; title: string; description: string; hashtags?: string; videoUrl: string; videoStorageKey?: string; thumbnailUrl?: string; thumbnailStorageKey?: string; durationMs: number; accessType?: "public" | "community" | "paid"; priceCents?: number }) {
  const db = await getDb();
  if (!db) throw new Error("Banco de dados indisponível.");
  const normalizedHashtags = normalizeHashtags(input.hashtags ?? `${input.title} ${input.description}`);
  const [created] = await db.insert(videos).values({ creatorId: input.creatorId, title: input.title, description: input.description, hashtags: normalizedHashtags, videoUrl: input.videoUrl, videoStorageKey: input.videoStorageKey, thumbnailUrl: input.thumbnailUrl, thumbnailStorageKey: input.thumbnailStorageKey, durationMs: input.durationMs, status: "published", visibility: "public", publishedAt: new Date() }).$returningId();
  if (input.accessType && input.accessType !== "public") {
    await db.insert(creatorContent).values({ creatorId: input.creatorId, videoId: created?.id, title: input.title, teaser: input.description, accessType: input.accessType, priceCents: input.priceCents ?? 0 });
  }
  return created;
}

export async function createModerationReport(input: { reporterId: number; targetUserId?: number; videoId?: number; liveRoomId?: number; reason: "spam" | "harassment" | "unsafe" | "copyright" | "other"; details?: string }) {
  const db = await getDb();
  if (!db) throw new Error("Banco de dados indisponível.");
  await db.insert(reports).values(input);
  return { created: true };
}

export async function blockUser(input: { blockerId: number; blockedUserId: number }) {
  const db = await getDb();
  if (!db) throw new Error("Banco de dados indisponível.");
  await db.insert(blocks).values(input).onDuplicateKeyUpdate({ set: { createdAt: new Date() } });
  return { blocked: true };
}


export async function getCommunityById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const [result] = await db.select({ community: communities, creator: users }).from(communities).innerJoin(users, eq(communities.creatorId, users.id)).where(eq(communities.id, id)).limit(1);
  return result;
}

export async function getCreatorContentById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const [result] = await db.select({ content: creatorContent, creator: users }).from(creatorContent).innerJoin(users, eq(creatorContent.creatorId, users.id)).where(eq(creatorContent.id, id)).limit(1);
  return result;
}
